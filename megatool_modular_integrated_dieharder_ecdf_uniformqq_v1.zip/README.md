# Megatool Modular Integrated Scaffold

This scaffold integrates a modular pipeline for entropy assessment and PDF reporting.

## What is integrated

- `compression` plugin computes a compression sanity check with standard Python compressors
- `dieharder` plugin calls `scripts/dieharder/dieharder_run_tests.sh`
- `sp80090b` plugin calls `scripts/sp80090b/run_sp80090b.sh`
- parsed outputs are stored as JSON in `results/parsed`
- normalized outputs are stored in `results/normalized`
- the final PDF is generated in `results/reports`
- the PDF includes:
  - compression summary table
  - SP800-90B summary
  - dieharder summary table
  - dieharder histogram of all p-values
  - dieharder QQ plot of normal scores derived from p-values

## Project layout

```text
megatool_modular_integrated/
├── configs/
├── core/
├── report/
│   └── charts/
├── results/
├── scripts/
│   ├── dieharder/
│   ├── sp80090b/
│   ├── run_full_assessment.py
│   └── run_full_assessment.sh
├── suites/
│   ├── compression/
│   ├── dieharder/
│   ├── sp80090b/
│   ├── sp80022/
│   └── lyapunov/
└── tools/
```

## Requirements

- Python 3.10+
- `reportlab`
- `PyYAML`
- `matplotlib`
- `dieharder` available in PATH
- compiled `ea_non_iid` binary from SP800-90B

## SP800-90B binary path

By default the pipeline expects:

```text
./tools/SP800-90B_EntropyAssessment/cpp/ea_non_iid
```

You can change it in:

```text
configs/suites/sp80090b.yaml
```

## Running the full pipeline

```bash
./scripts/run_full_assessment.sh --input /absolute/path/to/input.bin --bits 8
```

This executes:

1. compression sanity check
2. dieharder suite
3. SP800-90B non-IID suite
4. parsing and normalization
5. final PDF generation

## Current status

- `compression`: integrated and functional
- `dieharder`: integrated and functional
- `sp80090b`: integrated and functional
- `sp80022`: placeholder plugin
- `lyapunov`: placeholder plugin

## Adding a new suite

Each suite keeps the same interface:

- `runner.py`
- `parser.py`
- `normalizer.py`
- config file in `configs/suites/`

Then enable it in `configs/pipeline.yaml`.
