from __future__ import annotations

from core.types import SuiteArtifacts, SuiteContext


def normalize(ctx: SuiteContext, parsed: dict, artifacts: SuiteArtifacts) -> list[dict]:
    raise NotImplementedError("Lyapunov normalizer is a placeholder.")
