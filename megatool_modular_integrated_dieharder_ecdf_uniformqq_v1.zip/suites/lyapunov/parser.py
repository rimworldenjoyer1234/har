from __future__ import annotations

from core.types import SuiteArtifacts, SuiteContext


def parse(ctx: SuiteContext, artifacts: SuiteArtifacts) -> dict:
    raise NotImplementedError("Lyapunov parser is a placeholder.")
