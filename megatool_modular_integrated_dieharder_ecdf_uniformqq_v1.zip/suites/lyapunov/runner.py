from __future__ import annotations

from core.types import SuiteArtifacts, SuiteContext


def run(ctx: SuiteContext) -> SuiteArtifacts:
    raise NotImplementedError("Lyapunov runner is a placeholder. Add your coefficient or exponent computation here.")
