from __future__ import annotations

from core.types import SuiteArtifacts, SuiteContext


def normalize(ctx: SuiteContext, parsed: dict, artifacts: SuiteArtifacts) -> list[dict]:
    records = []
    threshold = parsed.get('suspicious_threshold_ratio')
    for row in parsed.get('algorithms', []):
        notes = []
        ratio = row.get('compression_ratio')
        if ratio is not None and threshold is not None and ratio < threshold:
            notes.append(f'ratio_below_threshold<{threshold}')
        records.append({
            'suite': ctx.suite_name,
            'test_name': f"Compression ratio ({row.get('algorithm')})",
            'category': 'compression_sanity',
            'scope': row.get('algorithm'),
            'value': ratio,
            'unit': 'compressed_over_raw',
            'status': 'SUSPICIOUS' if row.get('compressible') else 'OK',
            'reliable': True,
            'notes': notes,
            'raw_source': str(artifacts.raw_output) if artifacts.raw_output else None,
            'metrics': {
                'raw_size': row.get('raw_size'),
                'compressed_size': row.get('compressed_size'),
                'saved_bytes': row.get('saved_bytes'),
                'compressible': row.get('compressible'),
            },
        })
    return records
