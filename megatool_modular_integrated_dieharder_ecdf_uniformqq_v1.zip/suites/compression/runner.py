from __future__ import annotations

import bz2
import gzip
import json
import lzma
import zlib
from pathlib import Path

from core.types import SuiteArtifacts, SuiteContext


def _compress_metrics(name: str, data: bytes) -> dict:
    if name == 'zlib':
        compressed = zlib.compress(data, level=9)
    elif name == 'gzip':
        compressed = gzip.compress(data, compresslevel=9, mtime=0)
    elif name == 'bz2':
        compressed = bz2.compress(data, compresslevel=9)
    elif name == 'lzma':
        compressed = lzma.compress(data, preset=6)
    else:
        raise ValueError(f'Unsupported algorithm: {name}')

    raw_size = len(data)
    compressed_size = len(compressed)
    ratio = (compressed_size / raw_size) if raw_size else None
    saved_bytes = raw_size - compressed_size
    return {
        'algorithm': name,
        'raw_size': raw_size,
        'compressed_size': compressed_size,
        'compression_ratio': ratio,
        'space_saving_ratio': (saved_bytes / raw_size) if raw_size else None,
        'saved_bytes': saved_bytes,
        'compressible': compressed_size < raw_size,
    }


def run(ctx: SuiteContext) -> SuiteArtifacts:
    raw_dir = ctx.results_dir / 'raw'
    raw_dir.mkdir(parents=True, exist_ok=True)
    raw_path = raw_dir / f'{ctx.suite_name}.json'

    algorithms = ctx.suite_settings.get('algorithms') or ['zlib', 'gzip', 'bz2', 'lzma']
    data = Path(ctx.input_file).read_bytes()

    results = []
    for algorithm in algorithms:
        results.append(_compress_metrics(str(algorithm), data))

    best_ratio = min((r['compression_ratio'] for r in results if r['compression_ratio'] is not None), default=None)
    best_record = min(results, key=lambda x: x['compression_ratio'] if x['compression_ratio'] is not None else float('inf')) if results else None
    suspicious_threshold = float(ctx.suite_settings.get('suspicious_threshold_ratio', 0.995))

    payload = {
        'input_file': str(ctx.input_file),
        'raw_size': len(data),
        'algorithms': results,
        'best_ratio': best_ratio,
        'best_algorithm': best_record['algorithm'] if best_record else None,
        'best_saved_bytes': best_record['saved_bytes'] if best_record else None,
        'compressible': bool(best_record and best_record['compressible']),
        'suspicious_threshold_ratio': suspicious_threshold,
        'suspicious': bool(best_ratio is not None and best_ratio < suspicious_threshold),
    }

    raw_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
    return SuiteArtifacts(
        suite=ctx.suite_name,
        raw_output=raw_path,
        log_output=raw_path,
        metadata={'algorithms': algorithms},
    )
