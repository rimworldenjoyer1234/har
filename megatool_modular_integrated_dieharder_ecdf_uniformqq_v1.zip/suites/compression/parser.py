from __future__ import annotations

import json
from pathlib import Path

from core.types import SuiteArtifacts, SuiteContext


def parse(ctx: SuiteContext, artifacts: SuiteArtifacts) -> dict:
    return json.loads(Path(artifacts.raw_output).read_text(encoding='utf-8'))
