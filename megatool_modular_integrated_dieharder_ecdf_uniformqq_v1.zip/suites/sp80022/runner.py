from __future__ import annotations

from core.types import SuiteArtifacts, SuiteContext


def run(ctx: SuiteContext) -> SuiteArtifacts:
    raise NotImplementedError("SP800-22 runner is a placeholder. Connect your STS execution here.")
