from __future__ import annotations

from core.types import SuiteArtifacts, SuiteContext


def parse(ctx: SuiteContext, artifacts: SuiteArtifacts) -> dict:
    raise NotImplementedError("SP800-22 parser is a placeholder.")
