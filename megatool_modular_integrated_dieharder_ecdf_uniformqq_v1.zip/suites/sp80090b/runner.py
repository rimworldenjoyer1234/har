from __future__ import annotations

import subprocess
from pathlib import Path

from core.types import SuiteArtifacts, SuiteContext


def run(ctx: SuiteContext) -> SuiteArtifacts:
    base_dir = Path(__file__).resolve().parents[2]
    raw_dir = ctx.results_dir / 'raw'
    raw_dir.mkdir(parents=True, exist_ok=True)
    raw_path = raw_dir / f'{ctx.suite_name}.txt'

    bits = int(ctx.suite_settings.get('bits_per_symbol', ctx.bits_per_symbol))
    script_rel = ctx.suite_settings.get('script_path', './scripts/sp80090b/run_sp80090b.sh')
    binary_rel = ctx.suite_settings.get('binary_path', './tools/SP800-90B_EntropyAssessment/cpp/ea_non_iid')
    script_path = (base_dir / script_rel).resolve()
    binary_path = (base_dir / binary_rel).resolve() if not Path(binary_rel).is_absolute() else Path(binary_rel)
    if not script_path.exists():
        raise FileNotFoundError(f'SP800-90B runner script not found: {script_path}')
    if not binary_path.exists():
        raise FileNotFoundError(f'SP800-90B binary not found: {binary_path}')

    cmd = [str(script_path), '--input', str(ctx.input_file), '--bits', str(bits), '--bin', str(binary_path), '--output', str(raw_path)]
    proc = subprocess.run(cmd, capture_output=True, text=True, cwd=base_dir)
    if proc.returncode != 0:
        raise RuntimeError(f'SP800-90B runner failed with code {proc.returncode}: {proc.stderr or proc.stdout}')

    if proc.stdout:
        (ctx.results_dir / 'logs').mkdir(parents=True, exist_ok=True)
        stdout_path = ctx.results_dir / 'logs' / f'{ctx.suite_name}_stdout.txt'
        stdout_path.write_text(proc.stdout, encoding='utf-8')
    else:
        stdout_path = raw_path
    if proc.stderr:
        stderr_path = ctx.results_dir / 'logs' / f'{ctx.suite_name}_stderr.txt'
        stderr_path.write_text(proc.stderr, encoding='utf-8')
    else:
        stderr_path = None

    return SuiteArtifacts(
        suite=ctx.suite_name,
        raw_output=raw_path,
        log_output=stderr_path or stdout_path,
        metadata={'bits': bits, 'command': cmd},
    )
