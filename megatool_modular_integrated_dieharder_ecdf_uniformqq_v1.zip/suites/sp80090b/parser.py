from __future__ import annotations

import re
from pathlib import Path

from core.types import SuiteArtifacts, SuiteContext

OPENING_RE = re.compile(r"Opening file: '(.+?)' \(SHA-256 hash ([0-9a-fA-F]+)\)")
LOADED_RE = re.compile(r"Loaded\s+(\d+)\s+samples\s+of\s+(\d+)\s+distinct\s+(\d+)-bit-wide\s+symbols")
BIN_SYMBOLS_RE = re.compile(r"Number of Binary Symbols:\s+(\d+)")
ESTIMATE_RE = re.compile(r"^\s*(.+?Estimate(?: \(bit string\))?)\s*=\s*([0-9]+\.[0-9]+)\s*/\s*([0-9]+)\s+bit\(s\)")
FINAL_RE = re.compile(r"^(H_original|H_bitstring|min\(H_original, 8 X H_bitstring\)):\s*([0-9]+\.[0-9]+)")
SECTION_RE = re.compile(r"^Running\s+(.+?)\.\.\.$")


def parse(ctx: SuiteContext, artifacts: SuiteArtifacts) -> dict:
    text = Path(artifacts.raw_output).read_text(encoding='utf-8', errors='replace')
    lines = text.splitlines()
    data = {
        'file': None,
        'sha256': None,
        'samples': None,
        'distinct_symbols': None,
        'bits_per_symbol': None,
        'binary_symbols': None,
        'sections': [],
        'estimates': [],
        'final': {},
    }
    current_section = None
    seen_sections = []

    for line in lines:
        m = OPENING_RE.search(line)
        if m:
            data['file'] = m.group(1)
            data['sha256'] = m.group(2)
            continue
        m = LOADED_RE.search(line)
        if m:
            data['samples'] = int(m.group(1))
            data['distinct_symbols'] = int(m.group(2))
            data['bits_per_symbol'] = int(m.group(3))
            continue
        m = BIN_SYMBOLS_RE.search(line)
        if m:
            data['binary_symbols'] = int(m.group(1))
            continue
        m = SECTION_RE.match(line.strip())
        if m:
            current_section = m.group(1)
            seen_sections.append(current_section)
            continue
        m = ESTIMATE_RE.match(line)
        if m:
            data['estimates'].append({
                'section': current_section,
                'name': m.group(1).strip(),
                'value': float(m.group(2)),
                'bits': int(m.group(3)),
            })
            continue
        m = FINAL_RE.match(line.strip())
        if m:
            key = m.group(1)
            normalized_key = {
                'H_original': 'H_original',
                'H_bitstring': 'H_bitstring',
                'min(H_original, 8 X H_bitstring)': 'min_entropy_bound',
            }[key]
            data['final'][normalized_key] = float(m.group(2))

    data['sections'] = seen_sections
    return data
