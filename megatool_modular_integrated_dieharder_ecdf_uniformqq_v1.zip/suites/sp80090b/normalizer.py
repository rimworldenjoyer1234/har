from __future__ import annotations

from core.types import SuiteArtifacts, SuiteContext


def normalize(ctx: SuiteContext, parsed: dict, artifacts: SuiteArtifacts) -> list[dict]:
    records = []
    final = parsed.get('final', {})
    for key, unit, scope in [
        ('H_original', 'bits_per_symbol', 'literal'),
        ('H_bitstring', 'bits_per_bit', 'bitstring'),
        ('min_entropy_bound', 'bits_per_symbol', 'final'),
    ]:
        if key in final:
            records.append({
                'suite': ctx.suite_name,
                'test_name': key,
                'category': 'entropy_estimate',
                'scope': scope,
                'value': final[key],
                'unit': unit,
                'status': 'info',
                'reliable': True,
                'notes': [],
                'raw_source': str(artifacts.raw_output) if artifacts.raw_output else None,
            })
    for est in parsed.get('estimates', []):
        records.append({
            'suite': ctx.suite_name,
            'test_name': est.get('name'),
            'category': 'entropy_estimate',
            'scope': est.get('section'),
            'value': est.get('value'),
            'unit': f"bits_per_{est.get('bits')}",
            'status': 'info',
            'reliable': True,
            'notes': [],
            'raw_source': str(artifacts.raw_output) if artifacts.raw_output else None,
        })
    return records
