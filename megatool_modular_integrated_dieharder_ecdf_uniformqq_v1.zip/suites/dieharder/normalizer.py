from __future__ import annotations

from core.types import SuiteArtifacts, SuiteContext


def normalize(ctx: SuiteContext, parsed: dict, artifacts: SuiteArtifacts) -> list[dict]:
    records = []
    for test in parsed.get('summary_rows', []):
        notes = []
        rewind_flag = str(test.get('rewind_flag') or 'NONE').upper()
        reliability_note = str(test.get('reliability_note') or '')
        if rewind_flag != 'NONE':
            notes.append(f'rewind={rewind_flag}')
        if reliability_note and reliability_note != 'none':
            notes.append(reliability_note)
        records.append(
            {
                'suite': ctx.suite_name,
                'test_name': test.get('test_name'),
                'test_id': int(test['test_id']) if str(test.get('test_id', '')).isdigit() else None,
                'category': 'statistical_test',
                'value': test.get('overall_assessment'),
                'unit': 'assessment',
                'status': test.get('overall_assessment', 'UNKNOWN'),
                'reliable': rewind_flag == 'NONE' and str(test.get('status')).upper() != 'FAILED',
                'notes': notes,
                'scope': None,
                'raw_source': str(artifacts.metadata.get('summary_csv')),
                'metrics': {
                    'passed_count': test.get('passed_count', 0),
                    'weak_count': test.get('weak_count', 0),
                    'failed_count': test.get('failed_count', 0),
                    'assessment_rows': test.get('assessment_rows', 0),
                    'min_p': test.get('min_p'),
                    'max_p': test.get('max_p'),
                },
            }
        )
    return records
