from __future__ import annotations

import subprocess
from pathlib import Path

from core.types import SuiteArtifacts, SuiteContext


def _extract_info(stdout: str, key: str) -> str | None:
    prefix = f"[INFO] {key}:"
    for line in stdout.splitlines():
        if line.startswith(prefix):
            return line.split(':', 1)[1].strip()
    return None


def run(ctx: SuiteContext) -> SuiteArtifacts:
    results_dir = ctx.results_dir
    script_rel = ctx.suite_settings.get('script_path', './scripts/dieharder/dieharder_run_tests.sh')
    script_path = (Path(__file__).resolve().parents[2] / script_rel).resolve()
    if not script_path.exists():
        raise FileNotFoundError(f'dieharder runner script not found: {script_path}')

    cmd = [str(script_path), '--file', str(ctx.input_file), '--results-dir', str(results_dir)]
    if ctx.suite_settings.get('all_tests', True):
        cmd.append('--all')
    else:
        tests = ctx.suite_settings.get('tests')
        if not tests:
            raise ValueError('dieharder suite requires tests or all_tests=true')
        if isinstance(tests, (list, tuple)):
            tests = ','.join(str(t) for t in tests)
        cmd += ['--tests', str(tests)]

    generator = ctx.suite_settings.get('generator')
    if generator is not None:
        cmd += ['--generator', str(generator)]
    safety = ctx.suite_settings.get('safety')
    if safety is not None:
        cmd += ['--safety', str(safety)]
    fudge = ctx.suite_settings.get('fudge')
    if fudge is not None:
        cmd += ['--fudge', str(fudge)]
    psamples = ctx.suite_settings.get('psamples')
    if psamples is not None:
        cmd += ['--psamples', str(psamples)]
    ntuple = ctx.suite_settings.get('ntuple')
    if ntuple is not None:
        cmd += ['--ntuple', str(ntuple)]
    if ctx.suite_settings.get('verbose', True):
        cmd.append('--verbose')

    proc = subprocess.run(cmd, capture_output=True, text=True, cwd=Path(__file__).resolve().parents[2])
    if proc.returncode != 0:
        raise RuntimeError(f'dieharder runner failed with code {proc.returncode}: {proc.stderr or proc.stdout}')

    summary_csv = _extract_info(proc.stdout, 'Summary CSV')
    detail_csv = _extract_info(proc.stdout, 'Dieharder CSV')
    run_log = _extract_info(proc.stdout, 'Run log')
    if not summary_csv or not detail_csv:
        raise RuntimeError('dieharder runner did not report summary/detail CSV paths')

    stdout_path = results_dir / 'raw' / f'{ctx.suite_name}_stdout.txt'
    stdout_path.write_text(proc.stdout, encoding='utf-8')
    if proc.stderr:
        stderr_path = results_dir / 'logs' / f'{ctx.suite_name}_stderr.txt'
        stderr_path.write_text(proc.stderr, encoding='utf-8')
    else:
        stderr_path = None

    return SuiteArtifacts(
        suite=ctx.suite_name,
        raw_output=stdout_path,
        log_output=Path(run_log) if run_log else stderr_path,
        metadata={
            'command': cmd,
            'summary_csv': summary_csv,
            'detail_csv': detail_csv,
            'stdout_path': str(stdout_path),
            'stderr_path': str(stderr_path) if stderr_path else None,
        },
    )
