from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterable

from core.types import SuiteArtifacts, SuiteContext


def _to_float(value):
    if value is None:
        return None
    value = str(value).strip()
    if value == '':
        return None
    try:
        return float(value)
    except ValueError:
        return None


def _to_int(value, default=0):
    if value in (None, ''):
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _extract_pval_from_row(row: dict):
    candidates = [
        'p-value', 'p_value', 'pvalue', 'p', 'p value', 'P-value', 'P-Value',
        'p-value1', 'P-value1', 'pvalue1', 'pvalue_1',
    ]
    for key in candidates:
        if key in row:
            p = _to_float(row.get(key))
            if p is not None:
                return p
    for key, value in row.items():
        if key is None:
            continue
        key_l = str(key).strip().lower()
        if 'p-value' in key_l or key_l in {'p', 'pvalue', 'p_value'}:
            p = _to_float(value)
            if p is not None:
                return p
    return None


def _read_csv_rows(path: Path) -> list[dict]:
    rows: list[dict] = []
    if not path.exists() or path.stat().st_size == 0:
        return rows
    with open(path, 'r', encoding='utf-8', errors='replace', newline='') as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            return rows
        for row in reader:
            p = _extract_pval_from_row(row)
            if p is not None:
                row['p_value'] = p
            rows.append(row)
    return rows




def _read_pipe_pvalues(path: Path) -> list[dict]:
    rows: list[dict] = []
    if not path.exists() or path.stat().st_size == 0:
        return rows
    for line in path.read_text(encoding='utf-8', errors='replace').splitlines():
        line = line.strip()
        if not line.startswith('|') or not line.endswith('|'):
            continue
        raw = line.strip('|').strip()
        p = _to_float(raw)
        if p is None:
            continue
        rows.append({'p_value': p, 'source_txt': str(path)})
    return rows

def _stats_from_pvalues_file(path: Path) -> tuple[float | None, float | None, int]:
    rows = _read_pipe_pvalues(path)
    values = [r.get('p_value') for r in rows if r.get('p_value') is not None]
    if not values:
        return None, None, 0
    return min(values), max(values), len(values)


def _iter_pvalues_txt_paths(summary_rows: Iterable[dict]) -> Iterable[Path]:
    seen: set[str] = set()
    for row in summary_rows:
        raw_path = str(row.get('pvalues_txt_path') or '').strip()
        if not raw_path:
            continue
        if raw_path in seen:
            continue
        seen.add(raw_path)
        yield Path(raw_path)



def _iter_fallback_pvalues_txt_paths(summary_path: Path) -> Iterable[Path]:
    csv_dir = summary_path.parent / 'csv'
    if not csv_dir.exists() or not csv_dir.is_dir():
        return []
    return sorted(csv_dir.glob('test_*_pvalues.txt'))

def _iter_raw_csv_paths(summary_rows: Iterable[dict]) -> Iterable[Path]:
    seen: set[str] = set()
    for row in summary_rows:
        raw_path = str(row.get('raw_csv_path') or '').strip()
        if not raw_path:
            continue
        if raw_path in seen:
            continue
        seen.add(raw_path)
        yield Path(raw_path)


def parse(ctx: SuiteContext, artifacts: SuiteArtifacts) -> dict:
    summary_path = Path(artifacts.metadata['summary_csv'])
    detail_path = Path(artifacts.metadata['detail_csv'])
    summary_rows = []
    detail_rows = []

    with open(summary_path, 'r', encoding='utf-8', errors='replace', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            row['test_id'] = row.get('test_id') or row.get('test_num') or row.get('id')
            row['passed_count'] = _to_int(row.get('passed_rows') or row.get('passed_count'))
            row['weak_count'] = _to_int(row.get('weak_rows') or row.get('weak_count'))
            row['failed_count'] = _to_int(row.get('failed_rows') or row.get('failed_count'))
            row['assessment_rows'] = _to_int(row.get('assessment_rows'))
            row['min_p'] = _to_float(row.get('min_p'))
            row['max_p'] = _to_float(row.get('max_p'))
            row['pvalues_count'] = 0
            pvalues_txt = str(row.get('pvalues_txt_path') or '').strip()
            if pvalues_txt:
                pmin_all, pmax_all, pcount = _stats_from_pvalues_file(Path(pvalues_txt))
                if pcount > 0:
                    row['min_p'] = pmin_all
                    row['max_p'] = pmax_all
                    row['pvalues_count'] = pcount
            summary_rows.append(row)

    # First choice: combined CSV emitted by the dieharder runner.
    detail_rows.extend(_read_csv_rows(detail_path))

    # Fallback: some environments produce a combined CSV that is empty or difficult to parse.
    # In that case, re-read per-test CSVs referenced in the summary file so charts still work.
    if sum(1 for r in detail_rows if r.get('p_value') is not None) < 2:
        detail_rows = []
        for raw_csv_path in _iter_raw_csv_paths(summary_rows):
            rows = _read_csv_rows(raw_csv_path)
            test_id = raw_csv_path.stem
            for row in rows:
                row.setdefault('source_csv', str(raw_csv_path))
                row.setdefault('test_id_hint', test_id)
            detail_rows.extend(rows)

    # Preferred source for charting full psample distributions: dieharder -D 65536.
    # Merge these values in even when CSV rows are present, because CSV summaries often
    # contain only one aggregate p-value per assessment row.
    pipe_rows: list[dict] = []
    pvalue_paths = list(_iter_pvalues_txt_paths(summary_rows))
    if not pvalue_paths:
        pvalue_paths = list(_iter_fallback_pvalues_txt_paths(summary_path))
    for pvalues_txt_path in pvalue_paths:
        rows = _read_pipe_pvalues(pvalues_txt_path)
        test_id = pvalues_txt_path.stem
        for row in rows:
            row.setdefault('test_id_hint', test_id)
        pipe_rows.extend(rows)
    if pipe_rows:
        detail_rows = pipe_rows

    overall = {
        'tests_total': len(summary_rows),
        'tests_passed': sum(1 for r in summary_rows if str(r.get('overall_assessment', '')).upper() == 'PASSED'),
        'tests_weak': sum(1 for r in summary_rows if str(r.get('overall_assessment', '')).upper() == 'WEAK'),
        'tests_failed': sum(1 for r in summary_rows if str(r.get('overall_assessment', '')).upper() == 'FAILED'),
        'tests_skipped': sum(1 for r in summary_rows if str(r.get('status', '')).upper() == 'SKIPPED'),
        'tests_rewind_detected': sum(1 for r in summary_rows if str(r.get('rewind_flag', '')).upper() == 'DETECTED'),
        'tests_rewind_possible': sum(1 for r in summary_rows if str(r.get('rewind_flag', '')).upper() == 'POSSIBLE'),
        'detail_pvalues': sum(1 for r in detail_rows if r.get('p_value') is not None),
    }

    return {
        'suite': ctx.suite_name,
        'source': str(summary_path),
        'overall': overall,
        'summary_rows': summary_rows,
        'detail_rows': detail_rows,
    }
