#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from core.runner import PipelineRunner
from report.generate_pdf import build_report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='Run full modular assessment pipeline')
    parser.add_argument('--input', required=True, help='Input binary file')
    parser.add_argument('--bits', type=int, default=8, help='Bits per symbol')
    parser.add_argument('--config', default='./configs/pipeline.yaml', help='Pipeline config path')
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    base_dir = Path(__file__).resolve().parents[1]
    config_path = (base_dir / args.config).resolve() if not Path(args.config).is_absolute() else Path(args.config)
    input_file = Path(args.input).resolve()
    if not input_file.exists():
        raise FileNotFoundError(f'Input file not found: {input_file}')

    runner = PipelineRunner(base_dir=base_dir, pipeline_config=config_path)
    outputs = runner.run_all(input_file=input_file, bits_per_symbol=args.bits)
    pdf = build_report(base_dir=base_dir, input_file=input_file, suite_outputs=outputs)
    print(f'[INFO] PDF report: {pdf}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
