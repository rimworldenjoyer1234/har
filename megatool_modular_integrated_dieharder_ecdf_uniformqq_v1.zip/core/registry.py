from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from core.utils import load_yaml


class SuiteRegistry:
    def __init__(self, base_dir: Path, pipeline_config: Path):
        self.base_dir = base_dir
        self.pipeline_config = pipeline_config
        self.pipeline = load_yaml(pipeline_config)
        self.suites_dir = base_dir / "configs" / "suites"

    def enabled_suite_names(self) -> List[str]:
        return list(self.pipeline.get("enabled_suites", []))

    def suite_config(self, suite_name: str) -> Dict:
        cfg = load_yaml(self.suites_dir / f"{suite_name}.yaml")
        return cfg
