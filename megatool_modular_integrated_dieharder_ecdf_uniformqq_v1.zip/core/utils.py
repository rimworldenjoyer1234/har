from __future__ import annotations

import importlib
import json
from pathlib import Path
from typing import Any

import yaml


def load_yaml(path: Path) -> dict:
    with open(path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f) or {}
    return data


def dump_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def import_from_dotted_path(path: str):
    module = importlib.import_module(path)
    return module
