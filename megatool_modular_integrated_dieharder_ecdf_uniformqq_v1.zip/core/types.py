from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class SuiteContext:
    input_file: Path
    bits_per_symbol: int
    results_dir: Path
    suite_name: str
    suite_settings: Dict[str, Any]
    config_path: Optional[Path] = None
    extra_args: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SuiteArtifacts:
    suite: str
    raw_output: Optional[Path] = None
    parsed_output: Optional[Path] = None
    normalized_output: Optional[Path] = None
    log_output: Optional[Path] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class NormalizedRecord:
    suite: str
    test_name: str
    category: str
    value: Any
    unit: str
    status: str
    reliable: bool = True
    notes: List[str] = field(default_factory=list)
    scope: Optional[str] = None
    test_id: Optional[int] = None
    raw_source: Optional[str] = None
