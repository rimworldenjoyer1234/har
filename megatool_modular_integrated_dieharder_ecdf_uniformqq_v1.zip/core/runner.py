from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from core.registry import SuiteRegistry
from core.types import SuiteArtifacts, SuiteContext
from core.utils import dump_json, import_from_dotted_path


class PipelineRunner:
    def __init__(self, base_dir: Path, pipeline_config: Path):
        self.base_dir = base_dir
        self.registry = SuiteRegistry(base_dir, pipeline_config)
        self.pipeline_config = pipeline_config

    def run_all(self, input_file: Path, bits_per_symbol: int) -> Dict[str, dict]:
        results_dir = self.base_dir / self.registry.pipeline.get('results_dir', './results')
        for sub in ['raw', 'parsed', 'normalized', 'reports', 'logs']:
            (results_dir / sub).mkdir(parents=True, exist_ok=True)
        all_outputs: Dict[str, dict] = {}

        for suite_name in self.registry.enabled_suite_names():
            suite_cfg = self.registry.suite_config(suite_name)
            if not suite_cfg.get('enabled', True):
                continue

            ctx = SuiteContext(
                input_file=input_file,
                bits_per_symbol=bits_per_symbol,
                results_dir=results_dir,
                suite_name=suite_name,
                suite_settings=suite_cfg.get('settings', {}),
                config_path=self.pipeline_config,
            )

            runner_mod = import_from_dotted_path(suite_cfg['runner_module'])
            parser_mod = import_from_dotted_path(suite_cfg['parser_module'])
            normalizer_mod = import_from_dotted_path(suite_cfg['normalizer_module'])

            artifacts: SuiteArtifacts = runner_mod.run(ctx)
            parsed = parser_mod.parse(ctx, artifacts)
            parsed_path = results_dir / 'parsed' / f'{suite_name}.json'
            dump_json(parsed_path, parsed)
            artifacts.parsed_output = parsed_path

            normalized = normalizer_mod.normalize(ctx, parsed, artifacts)
            norm_path = results_dir / 'normalized' / f'{suite_name}.json'
            dump_json(norm_path, normalized)
            artifacts.normalized_output = norm_path
            all_outputs[suite_name] = {
                'parsed': parsed,
                'normalized': normalized,
                'artifacts': {
                    'raw_output': str(artifacts.raw_output) if artifacts.raw_output else None,
                    'parsed_output': str(artifacts.parsed_output) if artifacts.parsed_output else None,
                    'normalized_output': str(artifacts.normalized_output) if artifacts.normalized_output else None,
                    'log_output': str(artifacts.log_output) if artifacts.log_output else None,
                    'metadata': artifacts.metadata,
                },
            }

        return all_outputs
