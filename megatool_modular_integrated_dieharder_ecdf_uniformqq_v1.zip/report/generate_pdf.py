from __future__ import annotations

from datetime import datetime
from html import escape
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import KeepTogether
from reportlab.platypus import Image as RLImage
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from report.charts.dieharder_plots import create_dieharder_plots


BREAK_SEPARATORS = set('/\\_.-=,:;')


def _fmt(v, digits=6):
    if v is None:
        return '-'
    if isinstance(v, float):
        return f'{v:.{digits}f}'
    return str(v)


def _escape_text(value: object) -> str:
    return escape('' if value is None else str(value))


def _split_long_token(token: str, max_chunk: int) -> List[str]:
    if len(token) <= max_chunk:
        return [token]
    parts: List[str] = []
    buf = ''
    for ch in token:
        buf += ch
        if len(buf) >= max_chunk and ch in BREAK_SEPARATORS:
            parts.append(buf)
            buf = ''
    if buf:
        while len(buf) > max_chunk:
            parts.append(buf[:max_chunk])
            buf = buf[max_chunk:]
        if buf:
            parts.append(buf)
    return parts or [token]


def _wrap_text_to_br(value: object, *, max_line: int = 60, max_chunk: int = 28) -> str:
    text = '' if value is None else str(value)
    if not text:
        return '-'

    tokens = text.split(' ')
    lines: List[str] = []
    current = ''

    def push_current():
        nonlocal current
        if current:
            lines.append(current)
            current = ''

    for token in tokens:
        if not token:
            candidate = current + ' ' if current else ''
            if len(candidate) <= max_line:
                current = candidate
            else:
                push_current()
            continue

        token_parts = _split_long_token(token, max_chunk=max_chunk)
        if len(token_parts) == 1:
            part = token_parts[0]
            candidate = f'{current} {part}'.strip() if current else part
            if len(candidate) <= max_line:
                current = candidate
            else:
                push_current()
                if len(part) <= max_line:
                    current = part
                else:
                    lines.extend(_split_long_token(part, max_line))
            continue

        for idx, part in enumerate(token_parts):
            candidate = f'{current} {part}'.strip() if current else part
            if len(candidate) <= max_line and idx == 0:
                current = candidate
            else:
                push_current()
                current = part
        push_current()

    push_current()
    return '<br/>'.join(escape(line) for line in lines if line) or '-'


TABLE_BODY_STYLE = ParagraphStyle(
    'TableBody',
    fontName='Helvetica',
    fontSize=8,
    leading=10,
    textColor=colors.black,
    allowWidows=1,
    allowOrphans=1,
    wordWrap='LTR',
)

TABLE_HEADER_STYLE = ParagraphStyle(
    'TableHeader',
    parent=TABLE_BODY_STYLE,
    fontName='Helvetica-Bold',
    textColor=colors.HexColor('#2E3440'),
)

TABLE_CODE_STYLE = ParagraphStyle(
    'TableCode',
    parent=TABLE_BODY_STYLE,
    fontName='Courier',
    fontSize=7,
    leading=8.4,
)

SMALL_STYLE = ParagraphStyle(
    'Small',
    parent=TABLE_BODY_STYLE,
    fontSize=7.3,
    leading=9,
    textColor=colors.HexColor('#4C566A'),
)


def _p(value: object, style: ParagraphStyle = TABLE_BODY_STYLE) -> Paragraph:
    return Paragraph(_escape_text(value or '-'), style)


def _p_wrapped(value: object, *, max_line: int = 60, max_chunk: int = 28, style: ParagraphStyle = TABLE_BODY_STYLE) -> Paragraph:
    return Paragraph(_wrap_text_to_br(value, max_line=max_line, max_chunk=max_chunk), style)


def _style_table(table: Table, extra_styles: Optional[Sequence[Tuple]] = None):
    styles = [
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#E5E9F0')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor('#2E3440')),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.35, colors.HexColor('#D8DEE9')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F8F9FB')]),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 4.5),
        ('RIGHTPADDING', (0, 0), (-1, -1), 4.5),
        ('TOPPADDING', (0, 0), (-1, -1), 4.2),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4.2),
    ]
    if extra_styles:
        styles.extend(extra_styles)
    table.setStyle(TableStyle(styles))
    return table


def _build_table(rows: Sequence[Sequence], col_widths: Sequence[float], extra_styles: Optional[List[Tuple]] = None, *, repeat_rows: int = 1) -> Table:
    table = Table(rows, colWidths=col_widths, repeatRows=repeat_rows, splitByRow=1)
    return _style_table(table, extra_styles)


def _append_pipeline_summary(story, suite_outputs: Dict[str, dict], h1):
    story.append(Paragraph('Pipeline summary', h1))
    summary_rows = [[_p('Suite', TABLE_HEADER_STYLE), _p('Records', TABLE_HEADER_STYLE), _p('Raw output', TABLE_HEADER_STYLE)]]
    for suite_name, payload in suite_outputs.items():
        normalized = payload.get('normalized', [])
        art = payload.get('artifacts', {})
        summary_rows.append([
            _p(suite_name),
            _p(str(len(normalized))),
            _p_wrapped(art.get('raw_output') or '-', max_line=70, max_chunk=26),
        ])
    story.append(_build_table(summary_rows, [35 * mm, 20 * mm, 120 * mm]))
    story.append(Spacer(1, 5 * mm))


def _append_compression_section(story, payload: dict, h1, body):
    parsed = payload.get('parsed', {})
    if not parsed:
        return
    story.append(Paragraph('Compression sanity check', h1))
    suspicious = 'yes' if parsed.get('suspicious') else 'no'
    best_ratio = parsed.get('best_ratio')
    summary_rows = [
        [_p('Metric', TABLE_HEADER_STYLE), _p('Value', TABLE_HEADER_STYLE)],
        [_p('Raw size (bytes)'), _p(str(parsed.get('raw_size') or '-'))],
        [_p('Best algorithm'), _p(parsed.get('best_algorithm') or '-')],
        [_p('Best compressed/raw ratio'), _p(_fmt(best_ratio, 6))],
        [_p('Best saved bytes'), _p(str(parsed.get('best_saved_bytes') or 0))],
        [_p('Suspicious compression'), _p(suspicious)],
    ]
    story.append(_build_table(summary_rows, [60 * mm, 45 * mm]))
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph(
        'A noticeably compressible file is a warning sign because random-like data should not contain strong repetitive structure. '
        'The table below reports several standard compressors and their compressed/raw ratios.',
        body,
    ))
    story.append(Spacer(1, 2 * mm))
    algo_rows = [[
        _p('Algorithm', TABLE_HEADER_STYLE),
        _p('Raw bytes', TABLE_HEADER_STYLE),
        _p('Compressed bytes', TABLE_HEADER_STYLE),
        _p('Ratio', TABLE_HEADER_STYLE),
        _p('Saved bytes', TABLE_HEADER_STYLE),
        _p('Compressible', TABLE_HEADER_STYLE),
    ]]
    for row in parsed.get('algorithms', []):
        algo_rows.append([
            _p(row.get('algorithm') or '-'),
            _p(str(row.get('raw_size') or '-')),
            _p(str(row.get('compressed_size') or '-')),
            _p(_fmt(row.get('compression_ratio'), 6)),
            _p(str(row.get('saved_bytes') or 0)),
            _p('yes' if row.get('compressible') else 'no'),
        ])
    story.append(_build_table(algo_rows, [25 * mm, 28 * mm, 32 * mm, 25 * mm, 25 * mm, 22 * mm]))
    story.append(Spacer(1, 5 * mm))


def _append_sp80090b_section(story, payload: dict, h1):
    parsed = payload.get('parsed', {})
    if not parsed:
        return
    story.append(Paragraph('SP800-90B summary', h1))
    final = parsed.get('final', {})
    rows = [
        [_p('Metric', TABLE_HEADER_STYLE), _p('Value', TABLE_HEADER_STYLE)],
        [_p('H_original'), _p(_fmt(final.get('H_original')))],
        [_p('H_bitstring'), _p(_fmt(final.get('H_bitstring')))],
        [_p('min_entropy_bound'), _p(_fmt(final.get('min_entropy_bound')))],
    ]
    story.append(_build_table(rows, [60 * mm, 40 * mm]))
    est_rows = [[_p('Section', TABLE_HEADER_STYLE), _p('Estimate', TABLE_HEADER_STYLE), _p('Value', TABLE_HEADER_STYLE), _p('Bits', TABLE_HEADER_STYLE)]]
    for item in parsed.get('estimates', []):
        est_rows.append([
            _p_wrapped(item.get('section') or '-', max_line=28, max_chunk=20),
            _p_wrapped(item.get('name') or '-', max_line=54, max_chunk=26),
            _p(_fmt(item.get('value'))),
            _p(item.get('bits') or '-'),
        ])
    story.append(Spacer(1, 3 * mm))
    story.append(_build_table(est_rows[:40], [42 * mm, 98 * mm, 25 * mm, 15 * mm]))
    story.append(Spacer(1, 5 * mm))


def _append_dieharder_commands(story, summary_rows: list[dict], h1):
    command_rows: list[list] = []
    for row in summary_rows:
        command = (row.get('command') or '').strip()
        if not command:
            continue
        label = f"Test {row.get('test_id') or '-'} - {row.get('test_name') or '-'}"
        command_rows.append([
            Paragraph(f'<b>{escape(label)}</b><br/>{_wrap_text_to_br(command, max_line=120, max_chunk=32)}', TABLE_CODE_STYLE)
        ])
    if not command_rows:
        return

    story.append(Paragraph('dieharder execution commands', h1))
    story.append(Paragraph(
        'Commands are listed separately to keep the main results table compact and avoid page-split problems. '
        'Each command block wraps across lines when the full shell command is too long.',
        SMALL_STYLE,
    ))
    story.append(Spacer(1, 2 * mm))
    for block in command_rows:
        cmd_table = _build_table([block], [182 * mm], extra_styles=[
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F2F4F8')),
            ('GRID', (0, 0), (-1, -1), 0.35, colors.HexColor('#D8DEE9')),
            ('LEFTPADDING', (0, 0), (-1, -1), 6),
            ('RIGHTPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ], repeat_rows=0)
        story.append(KeepTogether([cmd_table, Spacer(1, 2 * mm)]))


def _append_dieharder_section(story, reports_dir: Path, payload: dict, h1, body, small):
    parsed = payload.get('parsed', {})
    if not parsed:
        return
    story.append(Paragraph('dieharder summary', h1))
    overall = parsed.get('overall', {})
    rows = [[_p('Metric', TABLE_HEADER_STYLE), _p('Value', TABLE_HEADER_STYLE)]]
    for key in ['tests_total', 'tests_passed', 'tests_weak', 'tests_failed', 'tests_skipped', 'tests_rewind_detected', 'tests_rewind_possible', 'detail_pvalues']:
        rows.append([_p(key), _p(str(overall.get(key, 0)))])
    story.append(_build_table(rows, [70 * mm, 30 * mm]))
    story.append(Spacer(1, 3 * mm))

    chart_info = create_dieharder_plots(parsed, reports_dir / 'charts')
    if chart_info.get('histogram') and chart_info.get('ecdf') and chart_info.get('qqplot_uniform'):
        story.append(Paragraph('dieharder p-value distribution', h1))
        story.append(Paragraph(
            'The histogram shows the overall spread of p-values. The ECDF is compared directly against the ideal Uniform(0,1) line, '
            'which is the natural reference for p-values. The quantile comparison also uses Uniform(0,1), so both axes stay in the [0,1] interval.',
            body,
        ))
        story.append(Spacer(1, 2 * mm))
        chart_rows = [
            [
                RLImage(str(chart_info['histogram']), width=84 * mm, height=46 * mm),
                RLImage(str(chart_info['ecdf']), width=84 * mm, height=46 * mm),
            ],
            [
                RLImage(str(chart_info['qqplot_uniform']), width=84 * mm, height=46 * mm),
                Paragraph('Quantile comparison against Uniform(0,1). Negative values are not expected here because the plot uses raw p-values rather than normal-score transforms.', small),
            ],
        ]
        chart_table = Table(chart_rows, colWidths=[86 * mm, 86 * mm])
        chart_table.setStyle(TableStyle([
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('LEFTPADDING', (0, 0), (-1, -1), 0),
            ('RIGHTPADDING', (0, 0), (-1, -1), 0),
            ('TOPPADDING', (0, 0), (-1, -1), 0),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ]))
        story.append(chart_table)
        story.append(Spacer(1, 1 * mm))
        story.append(Paragraph(
            f"P-values used in charts: {chart_info.get('pvalues_count', 0)}; mean p-value: {_fmt(chart_info.get('mean_p'), 4)}; variance: {_fmt(chart_info.get('variance_p'), 4)}.",
            small,
        ))
        story.append(Spacer(1, 4 * mm))
    else:
        story.append(Paragraph(
            f"No dieharder charts were generated because fewer than two parseable p-values were found in the dieharder outputs. Parsed p-values: {chart_info.get('pvalues_count', 0)}.",
            small,
        ))
        story.append(Spacer(1, 3 * mm))

    detail_rows = [[
        _p('ID', TABLE_HEADER_STYLE),
        _p('Test', TABLE_HEADER_STYLE),
        _p('Assessment', TABLE_HEADER_STYLE),
        _p('Pass', TABLE_HEADER_STYLE),
        _p('Weak', TABLE_HEADER_STYLE),
        _p('Fail', TABLE_HEADER_STYLE),
        _p('Min p', TABLE_HEADER_STYLE),
        _p('Max p', TABLE_HEADER_STYLE),
        _p('Reliable', TABLE_HEADER_STYLE),
    ]]
    for row in parsed.get('summary_rows', [])[:60]:
        reliable = 'yes' if str(row.get('rewind_flag', 'NONE')).upper() == 'NONE' and str(row.get('status', '')).upper() != 'FAILED' else 'no'
        detail_rows.append([
            _p(row.get('test_id') or '-'),
            _p_wrapped(row.get('test_name') or '-', max_line=30, max_chunk=22),
            _p(row.get('overall_assessment') or '-'),
            _p(str(row.get('passed_count', 0))),
            _p(str(row.get('weak_count', 0))),
            _p(str(row.get('failed_count', 0))),
            _p(_fmt(row.get('min_p'), 4)),
            _p(_fmt(row.get('max_p'), 4)),
            _p(reliable),
        ])
    story.append(_build_table(detail_rows, [10 * mm, 62 * mm, 24 * mm, 12 * mm, 12 * mm, 12 * mm, 15 * mm, 15 * mm, 18 * mm]))
    story.append(Spacer(1, 1.5 * mm))
    story.append(Paragraph(
        'Min p and Max p are computed from the full per-test p-value lists when available, not only from the aggregated assessment rows.',
        small,
    ))
    story.append(Spacer(1, 4 * mm))
    _append_dieharder_commands(story, parsed.get('summary_rows', [])[:60], h1)


def build_report(base_dir: Path, input_file: Path, suite_outputs: Dict[str, dict]) -> Path:
    reports_dir = base_dir / 'results' / 'reports'
    reports_dir.mkdir(parents=True, exist_ok=True)
    output_path = reports_dir / f'{input_file.stem}_assessment_report.pdf'

    styles = getSampleStyleSheet()
    title = ParagraphStyle('TitleX', parent=styles['Title'], fontName='Helvetica-Bold', fontSize=18, leading=22)
    h1 = ParagraphStyle('H1X', parent=styles['Heading1'], fontName='Helvetica-Bold', fontSize=12, leading=15)
    body = ParagraphStyle('BodyX', parent=styles['BodyText'], fontSize=9, leading=12)
    small = ParagraphStyle('SmallX', parent=styles['BodyText'], fontSize=8, leading=10, textColor=colors.HexColor('#4C566A'))

    story = [
        Paragraph('Entropy and Randomness Assessment Report', title),
        Spacer(1, 4 * mm),
        Paragraph(_wrap_text_to_br(f'Input file: {input_file}', max_line=95, max_chunk=36), body),
        Paragraph(f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}', small),
        Spacer(1, 4 * mm),
    ]

    _append_pipeline_summary(story, suite_outputs, h1)
    if 'compression' in suite_outputs:
        _append_compression_section(story, suite_outputs['compression'], h1, body)
    if 'sp80090b' in suite_outputs:
        _append_sp80090b_section(story, suite_outputs['sp80090b'], h1)
    if 'dieharder' in suite_outputs:
        _append_dieharder_section(story, reports_dir, suite_outputs['dieharder'], h1, body, small)

    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=14 * mm,
        rightMargin=14 * mm,
        topMargin=14 * mm,
        bottomMargin=14 * mm,
    )
    doc.build(story)
    return output_path
