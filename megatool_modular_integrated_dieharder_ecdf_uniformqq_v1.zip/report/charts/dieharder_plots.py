from __future__ import annotations

from pathlib import Path
from typing import Iterable

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def _extract_pvalues(rows: Iterable[dict]) -> list[float]:
    vals: list[float] = []
    for row in rows:
        value = row.get('p_value')
        if value is None:
            continue
        try:
            p = float(value)
        except (TypeError, ValueError):
            continue
        if 0.0 <= p <= 1.0:
            vals.append(p)
    return vals


def create_dieharder_plots(parsed: dict, out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    pvalues = _extract_pvalues(parsed.get('detail_rows', []))
    if len(pvalues) < 2:
        return {
            'pvalues_count': len(pvalues),
            'histogram': None,
            'ecdf': None,
            'qqplot_uniform': None,
        }

    hist_path = out_dir / 'dieharder_pvalues_hist.png'
    ecdf_path = out_dir / 'dieharder_pvalues_ecdf_uniform.png'
    qq_path = out_dir / 'dieharder_pvalues_qq_uniform.png'

    fig = plt.figure(figsize=(7.2, 3.8))
    ax = fig.add_subplot(1, 1, 1)
    ax.hist(pvalues, bins=20, range=(0.0, 1.0), edgecolor='black')
    ax.set_title('dieharder p-value histogram')
    ax.set_xlabel('p-value')
    ax.set_ylabel('Count')
    ax.set_xlim(0.0, 1.0)
    fig.tight_layout()
    fig.savefig(hist_path, dpi=180, bbox_inches='tight')
    plt.close(fig)

    n = len(pvalues)
    sorted_p = sorted(pvalues)
    ecdf_y = [i / n for i in range(1, n + 1)]

    fig = plt.figure(figsize=(7.2, 3.8))
    ax = fig.add_subplot(1, 1, 1)
    ax.step(sorted_p, ecdf_y, where='post', linewidth=1.4, label='Empirical CDF')
    ax.plot([0.0, 1.0], [0.0, 1.0], linestyle='--', linewidth=1.0, label='Uniform(0,1) ideal')
    ax.set_title('ECDF of dieharder p-values vs Uniform(0,1)')
    ax.set_xlabel('p-value')
    ax.set_ylabel('Cumulative probability')
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 1.0)
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(ecdf_path, dpi=180, bbox_inches='tight')
    plt.close(fig)

    theoretical = [(i - 0.5) / n for i in range(1, n + 1)]
    fig = plt.figure(figsize=(7.2, 3.8))
    ax = fig.add_subplot(1, 1, 1)
    ax.scatter(theoretical, sorted_p, s=10, alpha=0.75)
    ax.plot([0.0, 1.0], [0.0, 1.0], linestyle='--', linewidth=1.0)
    ax.set_title('Quantile comparison of dieharder p-values vs Uniform(0,1)')
    ax.set_xlabel('Theoretical Uniform(0,1) quantiles')
    ax.set_ylabel('Observed p-value quantiles')
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 1.0)
    fig.tight_layout()
    fig.savefig(qq_path, dpi=180, bbox_inches='tight')
    plt.close(fig)

    mean_p = sum(pvalues) / n
    variance_p = sum((p - mean_p) ** 2 for p in pvalues) / n
    return {
        'pvalues_count': n,
        'histogram': str(hist_path),
        'ecdf': str(ecdf_path),
        'qqplot_uniform': str(qq_path),
        'mean_p': mean_p,
        'variance_p': variance_p,
    }
