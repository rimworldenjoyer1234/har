from __future__ import annotations

import csv
from pathlib import Path

from core.types import SuiteArtifacts, SuiteContext


def _to_float(value):
    if value is None:
        return None
    value = str(value).strip()
    if value == '':
        return None
    try:
        return float(value)
    except ValueError:
        return None


def _to_int(value, default=0):
    if value in (None, ''):
        return default
    try:
        return int(value)
    except ValueError:
        return default


def parse(ctx: SuiteContext, artifacts: SuiteArtifacts) -> dict:
    summary_path = Path(artifacts.metadata['summary_csv'])
    detail_path = Path(artifacts.metadata['detail_csv'])
    summary_rows = []
    detail_rows = []

    with open(summary_path, 'r', encoding='utf-8', errors='replace', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            row['test_id'] = row.get('test_id') or row.get('test_num') or row.get('id')
            row['passed_count'] = _to_int(row.get('passed_rows') or row.get('passed_count'))
            row['weak_count'] = _to_int(row.get('weak_rows') or row.get('weak_count'))
            row['failed_count'] = _to_int(row.get('failed_rows') or row.get('failed_count'))
            row['assessment_rows'] = _to_int(row.get('assessment_rows'))
            row['min_p'] = _to_float(row.get('min_p'))
            row['max_p'] = _to_float(row.get('max_p'))
            summary_rows.append(row)

    if detail_path.exists() and detail_path.stat().st_size > 0:
        with open(detail_path, 'r', encoding='utf-8', errors='replace', newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                pval = row.get('p-value') or row.get('p_value') or row.get('pvalue') or row.get('p')
                row['p_value'] = _to_float(pval)
                detail_rows.append(row)

    overall = {
        'tests_total': len(summary_rows),
        'tests_passed': sum(1 for r in summary_rows if str(r.get('overall_assessment', '')).upper() == 'PASSED'),
        'tests_weak': sum(1 for r in summary_rows if str(r.get('overall_assessment', '')).upper() == 'WEAK'),
        'tests_failed': sum(1 for r in summary_rows if str(r.get('overall_assessment', '')).upper() == 'FAILED'),
        'tests_skipped': sum(1 for r in summary_rows if str(r.get('status', '')).upper() == 'SKIPPED'),
        'tests_rewind_detected': sum(1 for r in summary_rows if str(r.get('rewind_flag', '')).upper() == 'DETECTED'),
        'tests_rewind_possible': sum(1 for r in summary_rows if str(r.get('rewind_flag', '')).upper() == 'POSSIBLE'),
    }

    return {
        'suite': ctx.suite_name,
        'source': str(summary_path),
        'overall': overall,
        'summary_rows': summary_rows,
        'detail_rows': detail_rows,
    }
