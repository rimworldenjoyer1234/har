from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Dict

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def _fmt(v, digits=6):
    if v is None:
        return '-'
    if isinstance(v, float):
        return f'{v:.{digits}f}'
    return str(v)


def _style_table(table: Table):
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#E5E9F0')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor('#2E3440')),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.35, colors.HexColor('#D8DEE9')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F8F9FB')]),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('LEFTPADDING', (0, 0), (-1, -1), 5),
        ('RIGHTPADDING', (0, 0), (-1, -1), 5),
    ]))
    return table


def build_report(base_dir: Path, input_file: Path, suite_outputs: Dict[str, dict]) -> Path:
    reports_dir = base_dir / 'results' / 'reports'
    reports_dir.mkdir(parents=True, exist_ok=True)
    output_path = reports_dir / f'{input_file.stem}_assessment_report.pdf'

    styles = getSampleStyleSheet()
    title = ParagraphStyle('TitleX', parent=styles['Title'], fontName='Helvetica-Bold', fontSize=18, leading=22)
    h1 = ParagraphStyle('H1X', parent=styles['Heading1'], fontName='Helvetica-Bold', fontSize=12, leading=15)
    body = ParagraphStyle('BodyX', parent=styles['BodyText'], fontSize=9, leading=12)
    small = ParagraphStyle('SmallX', parent=styles['BodyText'], fontSize=8, leading=10, textColor=colors.HexColor('#4C566A'))

    story = []
    story.append(Paragraph('Entropy and Randomness Assessment Report', title))
    story.append(Spacer(1, 4*mm))
    story.append(Paragraph(f'Input file: {input_file}', body))
    story.append(Paragraph(f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}', small))
    story.append(Spacer(1, 4*mm))

    story.append(Paragraph('Pipeline summary', h1))
    summary_rows = [['Suite', 'Records', 'Raw output']]
    for suite_name, payload in suite_outputs.items():
        normalized = payload.get('normalized', [])
        art = payload.get('artifacts', {})
        summary_rows.append([suite_name, str(len(normalized)), art.get('raw_output') or '-'])
    story.append(_style_table(Table(summary_rows, colWidths=[35*mm, 20*mm, 120*mm], repeatRows=1)))
    story.append(Spacer(1, 5*mm))

    sp = suite_outputs.get('sp80090b', {})
    if sp:
        parsed = sp.get('parsed', {})
        story.append(Paragraph('SP800-90B summary', h1))
        final = parsed.get('final', {})
        rows = [['Metric', 'Value'], ['H_original', _fmt(final.get('H_original'))], ['H_bitstring', _fmt(final.get('H_bitstring'))], ['min_entropy_bound', _fmt(final.get('min_entropy_bound'))]]
        story.append(_style_table(Table(rows, colWidths=[60*mm, 40*mm], repeatRows=1)))
        est_rows = [['Section', 'Estimate', 'Value', 'Bits']]
        for item in parsed.get('estimates', []):
            est_rows.append([str(item.get('section') or '-'), str(item.get('name') or '-'), _fmt(item.get('value')), str(item.get('bits') or '-')])
        story.append(Spacer(1, 3*mm))
        story.append(_style_table(Table(est_rows[:40], colWidths=[45*mm, 95*mm, 25*mm, 15*mm], repeatRows=1)))
        story.append(Spacer(1, 5*mm))

    dh = suite_outputs.get('dieharder', {})
    if dh:
        parsed = dh.get('parsed', {})
        story.append(Paragraph('dieharder summary', h1))
        overall = parsed.get('overall', {})
        rows = [['Metric', 'Value']]
        for key in ['tests_total', 'tests_passed', 'tests_weak', 'tests_failed', 'tests_skipped', 'tests_rewind_detected', 'tests_rewind_possible']:
            rows.append([key, str(overall.get(key, 0))])
        story.append(_style_table(Table(rows, colWidths=[70*mm, 30*mm], repeatRows=1)))
        story.append(Spacer(1, 3*mm))
        detail = [['ID', 'Test', 'Assessment', 'Pass', 'Weak', 'Fail', 'Min p', 'Max p', 'Reliable']]
        for row in parsed.get('summary_rows', [])[:60]:
            reliable = 'yes' if str(row.get('rewind_flag', 'NONE')).upper() == 'NONE' and str(row.get('status', '')).upper() != 'FAILED' else 'no'
            detail.append([
                str(row.get('test_id') or '-'),
                str(row.get('test_name') or '-')[:38],
                str(row.get('overall_assessment') or '-'),
                str(row.get('passed_count', 0)),
                str(row.get('weak_count', 0)),
                str(row.get('failed_count', 0)),
                _fmt(row.get('min_p'), 4),
                _fmt(row.get('max_p'), 4),
                reliable,
            ])
        story.append(_style_table(Table(detail, colWidths=[10*mm, 62*mm, 24*mm, 12*mm, 12*mm, 12*mm, 15*mm, 15*mm, 18*mm], repeatRows=1)))

    doc = SimpleDocTemplate(str(output_path), pagesize=A4, leftMargin=14*mm, rightMargin=14*mm, topMargin=14*mm, bottomMargin=14*mm)
    doc.build(story)
    return output_path
