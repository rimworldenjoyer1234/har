# Megatool Modular Integrated Scaffold

This scaffold integrates the modular pipeline with the real `dieharder` Bash workflow and the real NIST SP800-90B `ea_non_iid` runner.

## What is integrated

- `dieharder` plugin calls `scripts/dieharder/dieharder_run_tests.sh`
- `sp80090b` plugin calls `scripts/sp80090b/run_sp80090b.sh`
- parsed outputs are stored as JSON in `results/parsed`
- normalized outputs are stored in `results/normalized`
- the final PDF is generated in `results/reports`

## Project layout

```text
megatool_modular_integrated/
├── configs/
├── core/
├── report/
├── results/
├── scripts/
│   ├── dieharder/
│   ├── sp80090b/
│   ├── run_full_assessment.py
│   └── run_full_assessment.sh
├── suites/
│   ├── dieharder/
│   ├── sp80090b/
│   ├── sp80022/
│   └── lyapunov/
└── tools/
```

## Requirements

- Python 3.10+
- `reportlab`
- `PyYAML`
- `dieharder` available in PATH
- compiled `ea_non_iid` binary from SP800-90B

## SP800-90B binary path

By default the pipeline expects:

```text
./tools/SP800-90B_EntropyAssessment/cpp/ea_non_iid
```

You can change it in:

```text
configs/suites/sp80090b.yaml
```

## Running the full pipeline

```bash
./scripts/run_full_assessment.sh --input /absolute/path/to/input.bin --bits 8
```

This executes:

1. dieharder suite
2. SP800-90B non-IID suite
3. parsing and normalization
4. final PDF generation

## Current status

- `dieharder`: integrated and functional
- `sp80090b`: integrated and functional
- `sp80022`: placeholder plugin
- `lyapunov`: placeholder plugin

## Adding a new suite

Each suite keeps the same interface:

- `runner.py`
- `parser.py`
- `normalizer.py`
- config file in `configs/suites/`

Then enable it in `configs/pipeline.yaml`.
