from __future__ import annotations
import json
from pathlib import Path
from core.types import SuiteArtifacts, SuiteContext
from suites.sp80022.native_impl import run_suite

def run(ctx: SuiteContext) -> SuiteArtifacts:
    raw_dir = ctx.results_dir / 'raw'; raw_dir.mkdir(parents=True, exist_ok=True)
    raw_path = raw_dir / f'{ctx.suite_name}.json'
    payload = run_suite(Path(ctx.input_file), ctx.suite_settings)
    raw_path.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    metadata = {'status': payload.get('status', 'ok'), 'native_implementation': True, 'sequence_length_bits': payload.get('sequence_length_bits'), 'bitstreams_effective': payload.get('bitstreams_effective'), 'selected_tests': payload.get('selected_tests')}
    return SuiteArtifacts(suite=ctx.suite_name, raw_output=raw_path, log_output=raw_path, metadata=metadata)
