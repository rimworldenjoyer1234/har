from __future__ import annotations
from core.types import SuiteArtifacts, SuiteContext

def normalize(ctx: SuiteContext, parsed: dict, artifacts: SuiteArtifacts) -> list[dict]:
    records = []; reliable_uniformity = parsed.get('overall', {}).get('sample_size', 0) >= 55; reliable_prop = parsed.get('overall', {}).get('sample_size', 0) >= 10
    for row in parsed.get('rows', []):
        notes = []
        if row.get('proportion_ok') is False: notes.append('proportion_below_threshold')
        if row.get('uniformity_ok') is False: notes.append('uniformity_below_threshold')
        records.append({'suite': ctx.suite_name, 'test_name': row.get('test_name'), 'category': 'sp80022_native', 'scope': f"row_{row.get('report_index')}", 'value': row.get('proportion'), 'unit': 'pass_proportion', 'status': 'pass' if row.get('proportion_ok') is not False else 'review', 'reliable': reliable_prop, 'notes': notes, 'raw_source': str(artifacts.raw_output) if artifacts.raw_output else None})
        records.append({'suite': ctx.suite_name, 'test_name': f"{row.get('test_name')} uniformity", 'category': 'sp80022_native', 'scope': f"row_{row.get('report_index')}", 'value': row.get('uniformity_pvalue'), 'unit': 'pvalue_of_pvalues', 'status': 'pass' if row.get('uniformity_ok') is not False else 'review', 'reliable': reliable_uniformity, 'notes': notes, 'raw_source': str(artifacts.raw_output) if artifacts.raw_output else None})
    return records
