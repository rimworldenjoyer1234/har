from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Sequence

import numpy as np
from scipy.fft import fft
from scipy.special import erfc, gammaincc, gammaln
from scipy.stats import norm

ALPHA_DEFAULT = 0.01
TEST_ORDER = [
    "Frequency",
    "Block Frequency",
    "Runs",
    "Longest Runs of Ones",
    "Rank",
    "Spectral - Discrete Fourier Transform",
    "Non-overlapping Template Matching",
    "Overlapping Template Matching",
    "Universal Statistical",
    "Linear Complexity",
    "Serial",
    "Approximate Entropy",
    "Cumulative Sums",
    "Random Excursions",
    "Random Excursions Variant",
]
UNIVERSAL_EXPECTED = {6: 5.2177052,7: 6.1962507,8: 7.1836656,9: 8.1764248,10: 9.1723243,11: 10.170032,12: 11.168765,13: 12.168070,14: 13.167693,15: 14.167488,16: 15.167379}
UNIVERSAL_VARIANCE = {6: 2.954,7: 3.125,8: 3.238,9: 3.311,10: 3.356,11: 3.384,12: 3.401,13: 3.410,14: 3.416,15: 3.419,16: 3.421}

@dataclass
class TestResult:
    test_name: str
    pvalue: float | None
    passed: bool | None
    details: Dict[str, Any]
    applicable: bool = True
    subtest: str | None = None

def bits_from_file(path: Path) -> np.ndarray:
    arr = np.fromfile(path, dtype=np.uint8)
    if arr.size == 0:
        return np.array([], dtype=np.uint8)
    return np.unpackbits(arr)

def split_streams(bits: np.ndarray, stream_len: int, requested: int | None = None, auto: bool = True) -> list[np.ndarray]:
    available = bits.size // stream_len
    count = available if auto else min(available, requested or 0)
    if auto and requested and requested > 0:
        count = min(count, requested)
    return [bits[i*stream_len:(i+1)*stream_len] for i in range(count)]

def _safe_p(p):
    if p is None or math.isnan(p) or math.isinf(p):
        return None
    return max(0.0, min(1.0, float(p)))

def _status_from_p(p, alpha):
    return None if p is None else (p >= alpha)

def _pack_rows32(block_bits: np.ndarray) -> np.ndarray:
    m = block_bits.reshape(32, 32)
    packed = np.packbits(m, axis=1, bitorder='big').astype(np.uint8)
    return ((packed[:,0].astype(np.uint32)<<24)|(packed[:,1].astype(np.uint32)<<16)|(packed[:,2].astype(np.uint32)<<8)|packed[:,3].astype(np.uint32))

def _gf2_rank_uint32(rows: np.ndarray) -> int:
    rows = rows.copy().astype(np.uint32)
    rank = 0
    for col in range(31, -1, -1):
        pivot = None
        for r in range(rank, 32):
            if (rows[r] >> col) & 1:
                pivot = r
                break
        if pivot is None:
            continue
        if pivot != rank:
            rows[[rank, pivot]] = rows[[pivot, rank]]
        pr = rows[rank]
        for r in range(32):
            if r != rank and ((rows[r] >> col) & 1):
                rows[r] ^= pr
        rank += 1
        if rank == 32:
            break
    return rank

def _generate_aperiodic_templates(m: int, limit: int | None = None) -> list[np.ndarray]:
    out = []
    for value in range(1, 2**m - 1):
        bits = np.array([(value >> (m-1-i)) & 1 for i in range(m)], dtype=np.uint8)
        periodic = False
        for p in range(1, m):
            if all(bits[i] == bits[i+p] for i in range(m-p)):
                periodic = True
                break
        if not periodic:
            out.append(bits)
            if limit and len(out) >= limit:
                break
    return out

def _overlap_probs(eta: float, k: int = 5) -> list[float]:
    probs = []
    for u in range(k):
        if u == 0:
            probs.append(float(math.exp(-eta)))
            continue
        total = 0.0
        for l in range(1, u+1):
            total += math.exp(-eta - u*math.log(2.0) + l*math.log(eta) - gammaln(l+1) + gammaln(u+1) - gammaln(l) - gammaln(u-l+1))
        probs.append(float(total))
    probs.append(max(0.0, 1.0 - sum(probs)))
    return probs

def _berlekamp_massey(block: np.ndarray) -> int:
    n = len(block)
    c = np.zeros(n, dtype=np.uint8); b = np.zeros(n, dtype=np.uint8)
    c[0] = 1; b[0] = 1; L = 0; m = -1
    for N in range(n):
        d = int(block[N])
        for i in range(1, L+1):
            d ^= int(c[i] & block[N-i])
        if d == 1:
            t = c.copy(); shift = N - m; c[shift:] ^= b[:n-shift]
            if L <= N/2:
                L = N + 1 - L; m = N; b = t
    return int(L)

def _pattern_counts(bits: np.ndarray, m: int) -> np.ndarray:
    ext = np.concatenate([bits, bits[:m-1]]) if m > 1 else bits.copy()
    counts = np.zeros(2**m, dtype=np.int64); mask = (1<<m)-1; v = 0
    for i in range(m):
        v = ((v<<1) | int(ext[i])) & mask
    counts[v] += 1
    for i in range(m, bits.size + m - 1):
        v = ((v<<1) | int(ext[i])) & mask
        counts[v] += 1
    return counts

def _cusum_pvalue(bits: np.ndarray, reverse=False) -> float:
    x = 2*bits.astype(np.int64) - 1
    if reverse:
        x = x[::-1]
    s = np.cumsum(x); z = int(np.max(np.abs(s))); n = bits.size
    if z == 0:
        return 1.0
    term1 = 0.0
    for k in range(int(math.floor((-n/z + 1)/4.0)), int(math.floor((n/z - 1)/4.0))+1):
        term1 += norm.cdf((4*k + 1)*z/math.sqrt(n)) - norm.cdf((4*k - 1)*z/math.sqrt(n))
    term2 = 0.0
    for k in range(int(math.floor((-n/z - 3)/4.0)), int(math.floor((n/z - 1)/4.0))+1):
        term2 += norm.cdf((4*k + 3)*z/math.sqrt(n)) - norm.cdf((4*k + 1)*z/math.sqrt(n))
    return _safe_p(1.0 - term1 + term2) or 0.0

def _build_cycles(bits: np.ndarray):
    x = 2*bits.astype(np.int64) - 1
    s = np.cumsum(x)
    s_prime = np.concatenate([[0], s, [0]])
    zero_idx = np.where(s_prime == 0)[0]
    cycles = [s_prime[zero_idx[i]:zero_idx[i+1]+1] for i in range(len(zero_idx)-1)]
    return s_prime, cycles

def _uniformity_bins(pvalues: Sequence[float]) -> tuple[list[int], float | None]:
    if not pvalues:
        return [0]*10, None
    bins = [0]*10
    for p in pvalues:
        bins[min(9, int(p*10.0))] += 1
    expected = len(pvalues)/10.0
    chi2 = sum((b-expected)**2/expected for b in bins) if expected else 0.0
    return bins, _safe_p(gammaincc(9/2.0, chi2/2.0))

def _min_pass_rate(alpha: float, sample_size: int) -> float | None:
    if sample_size <= 0:
        return None
    phat = 1.0 - alpha
    return phat - 3.0*math.sqrt((phat*alpha)/sample_size)

def frequency_test(bits, alpha):
    n = bits.size; s = abs(np.sum(2*bits - 1))/math.sqrt(n); p = _safe_p(erfc(s/math.sqrt(2.0)))
    return [TestResult('Frequency', p, _status_from_p(p, alpha), {'n': int(n), 's_obs': float(s)})]

def block_frequency_test(bits, alpha, M=128):
    n = bits.size; N = n//M
    if N < 1:
        return [TestResult('Block Frequency', None, None, {'reason': 'sequence_too_short', 'M': M}, applicable=False)]
    blocks = bits[:N*M].reshape(N, M); pis = blocks.mean(axis=1); chi2 = 4.0*M*np.sum((pis - 0.5)**2)
    p = _safe_p(gammaincc(N/2.0, chi2/2.0))
    return [TestResult('Block Frequency', p, _status_from_p(p, alpha), {'M': M, 'N': int(N), 'chi2': float(chi2)})]

def runs_test(bits, alpha):
    n = bits.size; pi = bits.mean(); tau = 2.0/math.sqrt(n)
    if abs(pi - 0.5) >= tau:
        return [TestResult('Runs', 0.0, False, {'reason': 'frequency_prerequisite_failed', 'pi': float(pi), 'tau': float(tau)})]
    vobs = 1 + int(np.sum(bits[1:] != bits[:-1])); num = abs(vobs - 2.0*n*pi*(1.0-pi)); den = 2.0*math.sqrt(2.0*n)*pi*(1.0-pi)
    p = _safe_p(erfc(num/den))
    return [TestResult('Runs', p, _status_from_p(p, alpha), {'pi': float(pi), 'vobs': vobs})]

def longest_run_ones_test(bits, alpha):
    n = bits.size
    if n < 128:
        return [TestResult('Longest Runs of Ones', None, None, {'reason': 'sequence_too_short'}, applicable=False)]
    if n < 6272:
        M, K, pi = 8, 3, [0.2148,0.3672,0.2305,0.1875]
        mapper = lambda r: 0 if r <= 1 else 1 if r == 2 else 2 if r == 3 else 3
    elif n < 750000:
        M, K, pi = 128, 5, [0.1174,0.2430,0.2493,0.1752,0.1027,0.1124]
        mapper = lambda r: 0 if r <= 4 else 1 if r == 5 else 2 if r == 6 else 3 if r == 7 else 4 if r == 8 else 5
    else:
        M, K, pi = 10000, 6, [0.0882,0.2092,0.2483,0.1933,0.1208,0.0675,0.0727]
        mapper = lambda r: 0 if r <= 10 else 1 if r == 11 else 2 if r == 12 else 3 if r == 13 else 4 if r == 14 else 5 if r == 15 else 6
    N = n//M; blocks = bits[:N*M].reshape(N, M); counts = [0]*(K+1)
    for block in blocks:
        max_run = run = 0
        for b in block:
            if b == 1:
                run += 1; max_run = max(max_run, run)
            else:
                run = 0
        counts[mapper(max_run)] += 1
    chi2 = sum((counts[i] - N*pi[i])**2/(N*pi[i]) for i in range(K+1)); p = _safe_p(gammaincc(K/2.0, chi2/2.0))
    return [TestResult('Longest Runs of Ones', p, _status_from_p(p, alpha), {'M': M, 'N': int(N), 'chi2': float(chi2), 'counts': counts})]

def rank_test(bits, alpha):
    block_len = 1024; N = bits.size//block_len
    if N < 38:
        return [TestResult('Rank', None, None, {'reason': 'sequence_too_short', 'required_blocks': 38}, applicable=False)]
    trimmed = bits[:N*block_len].reshape(N, block_len); ranks = []
    for block in trimmed:
        ranks.append(_gf2_rank_uint32(_pack_rows32(block)))
    ranks = np.array(ranks); FM = int(np.sum(ranks == 32)); FM1 = int(np.sum(ranks == 31)); rem = int(N - FM - FM1)
    chi2 = ((FM - 0.2888*N)**2/(0.2888*N) + (FM1 - 0.5776*N)**2/(0.5776*N) + (rem - 0.1336*N)**2/(0.1336*N))
    p = _safe_p(math.exp(-chi2/2.0))
    return [TestResult('Rank', p, _status_from_p(p, alpha), {'N': int(N), 'FM': FM, 'FM1': FM1, 'rem': rem, 'chi2': float(chi2)})]

def spectral_test(bits, alpha):
    n = bits.size
    if n < 1000:
        return [TestResult('Spectral - Discrete Fourier Transform', None, None, {'reason': 'sequence_too_short'}, applicable=False)]
    x = 2*bits.astype(np.int16) - 1; s = np.abs(fft(x))[:n//2]; T = math.sqrt(math.log(1/0.05)*n); N0 = 0.95*n/2.0; N1 = int(np.sum(s < T)); d = (N1 - N0)/math.sqrt(n*0.95*0.05/4.0)
    p = _safe_p(erfc(abs(d)/math.sqrt(2.0)))
    return [TestResult('Spectral - Discrete Fourier Transform', p, _status_from_p(p, alpha), {'N1': N1, 'N0': float(N0), 'd': float(d)})]

def non_overlapping_template_test(bits, alpha, m=9, template_limit=16):
    n = bits.size; N = 8; M = n//N
    if M <= m or M <= int(0.01*n):
        return [TestResult('Non-overlapping Template Matching', None, None, {'reason': 'sequence_too_short_or_bad_parameters', 'm': m}, applicable=False)]
    templates = _generate_aperiodic_templates(m, limit=template_limit)
    mu = (M - m + 1)/(2.0**m); var = M*((1.0/(2.0**m)) - ((2.0*m - 1.0)/(2.0**(2*m)))); blocks = bits[:N*M].reshape(N, M)
    results = []
    for idx, templ in enumerate(templates, start=1):
        W = []
        for block in blocks:
            count = 0; pos = 0
            while pos <= M - m:
                if np.array_equal(block[pos:pos+m], templ):
                    count += 1; pos += m
                else:
                    pos += 1
            W.append(count)
        chi2 = sum((w - mu)**2/var for w in W); p = _safe_p(gammaincc(N/2.0, chi2/2.0)); template = ''.join(map(str, templ.tolist()))
        results.append(TestResult(f'Non-overlapping Template Matching [{template}]', p, _status_from_p(p, alpha), {'template_index': idx, 'template': template, 'm': m, 'chi2': float(chi2), 'counts': W}, subtest=f'template_{idx}'))
    return results

def overlapping_template_test(bits, alpha, m=9, M=1032, K=5):
    n = bits.size; N = n//M
    if N < 1:
        return [TestResult('Overlapping Template Matching', None, None, {'reason': 'sequence_too_short', 'M': M}, applicable=False)]
    template = np.ones(m, dtype=np.uint8); v = [0]*(K+1); blocks = bits[:N*M].reshape(N, M)
    for block in blocks:
        count = 0
        for pos in range(M - m + 1):
            if np.array_equal(block[pos:pos+m], template):
                count += 1
        v[min(count, K)] += 1
    lam = (M - m + 1)/(2.0**m); eta = lam/2.0; pi = _overlap_probs(eta, K); chi2 = sum((v[i]-N*pi[i])**2/(N*pi[i]) for i in range(K+1) if pi[i] > 0); p = _safe_p(gammaincc(K/2.0, chi2/2.0))
    return [TestResult('Overlapping Template Matching', p, _status_from_p(p, alpha), {'m': m, 'M': M, 'N': int(N), 'chi2': float(chi2), 'counts': v, 'pi': pi})]

def universal_test(bits, alpha):
    n = bits.size; L = None
    thresholds = [(387840,6),(904960,7),(2068480,8),(4654080,9),(10342400,10),(22753280,11),(49643520,12),(107560960,13),(231669760,14),(496435200,15),(1059061760,16)]
    for thresh, Lv in thresholds:
        if n >= thresh: L = Lv
    if L is None:
        return [TestResult('Universal Statistical', None, None, {'reason': 'sequence_too_short'}, applicable=False)]
    Q = 10*(2**L); nblocks = n//L; K = nblocks - Q
    if K <= 0:
        return [TestResult('Universal Statistical', None, None, {'reason': 'insufficient_blocks', 'L': L}, applicable=False)]
    blocks = bits[:nblocks*L].reshape(nblocks, L).astype(np.int64)
    weights = (1 << np.arange(L-1, -1, -1, dtype=np.int64))
    ints = (blocks * weights).sum(axis=1).astype(np.int64)
    T = np.zeros(2**L, dtype=np.int64)
    for i in range(Q): T[ints[i]] = i + 1
    s = 0.0
    for i in range(Q, Q + K):
        dist = i + 1 - T[ints[i]]; T[ints[i]] = i + 1; s += math.log2(dist)
    fn = s/K; c = 0.7 - 0.8/L + (4.0 + 32.0/L)*(K**(-3.0/L))/15.0; sigma = c*math.sqrt(UNIVERSAL_VARIANCE[L]/K); p = _safe_p(erfc(abs(fn - UNIVERSAL_EXPECTED[L])/(math.sqrt(2.0)*sigma)))
    return [TestResult('Universal Statistical', p, _status_from_p(p, alpha), {'L': L, 'Q': int(Q), 'K': int(K), 'fn': float(fn), 'sigma': float(sigma)})]

def linear_complexity_test(bits, alpha, M=1000):
    n = bits.size; N = n//M
    if M < 500 or M > 5000 or N < 200:
        return [TestResult('Linear Complexity', None, None, {'reason': 'parameter_constraints', 'M': M, 'N': int(N)}, applicable=False)]
    blocks = bits[:N*M].reshape(N, M); Lvals = np.array([_berlekamp_massey(block) for block in blocks], dtype=float); mu = M/2.0 + (9.0 + (-1.0)**(M+1))/36.0 - ((M/3.0)+(2.0/9.0))/(2.0**M); T = ((-1.0)**M)*(Lvals - mu) + 2.0/9.0
    v = [int(np.sum(T <= -2.5)), int(np.sum((T > -2.5) & (T <= -1.5))), int(np.sum((T > -1.5) & (T <= -0.5))), int(np.sum((T > -0.5) & (T <= 0.5))), int(np.sum((T > 0.5) & (T <= 1.5))), int(np.sum((T > 1.5) & (T <= 2.5))), int(np.sum(T > 2.5))]
    pi = [0.010417,0.03125,0.125,0.5,0.25,0.0625,0.020833]; chi2 = sum((v[i]-N*pi[i])**2/(N*pi[i]) for i in range(7)); p = _safe_p(gammaincc(6/2.0, chi2/2.0))
    return [TestResult('Linear Complexity', p, _status_from_p(p, alpha), {'M': M, 'N': int(N), 'mu': float(mu), 'chi2': float(chi2), 'counts': v})]

def serial_test(bits, alpha, m=3):
    n = bits.size
    if m < 2 or m >= int(math.floor(math.log2(n)) - 2):
        m = max(2, int(math.floor(math.log2(n)) - 3))
    if m < 2:
        return [TestResult('Serial', None, None, {'reason': 'sequence_too_short'}, applicable=False)]
    psi = {}
    for mm in [m, m-1, m-2]:
        if mm <= 0: psi[mm] = 0.0; continue
        counts = _pattern_counts(bits, mm); psi[mm] = float((np.sum(counts.astype(np.float64)**2)*(2.0**mm)/n) - n)
    delta1 = psi[m] - psi[m-1]; delta2 = psi[m] - 2.0*psi[m-1] + psi[m-2]
    p1 = _safe_p(gammaincc((2**(m-1))/2.0, delta1/2.0)); p2 = _safe_p(gammaincc((2**(m-2))/2.0, delta2/2.0))
    return [TestResult('Serial [p1]', p1, _status_from_p(p1, alpha), {'m': m, 'delta1': float(delta1)}, subtest='p1'), TestResult('Serial [p2]', p2, _status_from_p(p2, alpha), {'m': m, 'delta2': float(delta2)}, subtest='p2')]

def approximate_entropy_test(bits, alpha, m=2):
    n = bits.size
    if m >= int(math.floor(math.log2(n)) - 5):
        m = max(2, int(math.floor(math.log2(n)) - 6))
    if m < 1:
        return [TestResult('Approximate Entropy', None, None, {'reason': 'sequence_too_short'}, applicable=False)]
    def phi(mm):
        ext = np.concatenate([bits, bits[:mm-1]]) if mm > 1 else bits.copy(); counts = np.zeros(2**mm, dtype=np.int64); mask = (1<<mm)-1; v = 0
        for i in range(mm): v = ((v<<1)|int(ext[i])) & mask
        counts[v] += 1
        for i in range(mm, n + mm - 1): v = ((v<<1)|int(ext[i])) & mask; counts[v] += 1
        C = counts[counts > 0]/float(n); return float(np.sum(C*np.log(C)))
    phi_m = phi(m); phi_m1 = phi(m+1); apen = phi_m - phi_m1; chi2 = 2.0*n*(math.log(2.0) - apen); p = _safe_p(gammaincc((2**(m-1))/2.0, chi2/2.0))
    return [TestResult('Approximate Entropy', p, _status_from_p(p, alpha), {'m': m, 'ApEn': float(apen), 'chi2': float(chi2)})]

def cumulative_sums_test(bits, alpha):
    pf = _cusum_pvalue(bits, reverse=False); pr = _cusum_pvalue(bits, reverse=True)
    return [TestResult('Cumulative Sums [forward]', pf, _status_from_p(pf, alpha), {'mode': 'forward'}, subtest='forward'), TestResult('Cumulative Sums [reverse]', pr, _status_from_p(pr, alpha), {'mode': 'reverse'}, subtest='reverse')]

def random_excursions_test(bits, alpha):
    s_prime, cycles = _build_cycles(bits); J = int(np.sum(s_prime[1:] == 0))
    if J < 500:
        return [TestResult('Random Excursions', None, None, {'reason': 'insufficient_cycles', 'J': J}, applicable=False)]
    states = [-4,-3,-2,-1,1,2,3,4]; results = []
    for x in states:
        counts = [0]*6; ax = abs(x); pi = [0.0]*6; pi[0] = 1.0 - 1.0/(2.0*ax)
        for k in range(1,5): pi[k] = (1.0/(4.0*ax*ax))*((1.0 - 1.0/(2.0*ax))**(k-1))
        pi[5] = (1.0/(2.0*ax))*((1.0 - 1.0/(2.0*ax))**4)
        for cyc in cycles: counts[min(int(np.sum(cyc == x)), 5)] += 1
        chi2 = sum((counts[k]-J*pi[k])**2/(J*pi[k]) for k in range(6) if pi[k] > 0); p = _safe_p(gammaincc(5/2.0, chi2/2.0))
        results.append(TestResult(f'Random Excursions [state {x}]', p, _status_from_p(p, alpha), {'state': x, 'J': J, 'chi2': float(chi2), 'counts': counts}, subtest=str(x)))
    return results

def random_excursions_variant_test(bits, alpha):
    s_prime, cycles = _build_cycles(bits); J = int(np.sum(s_prime[1:] == 0))
    if J < 500:
        return [TestResult('Random Excursions Variant', None, None, {'reason': 'insufficient_cycles', 'J': J}, applicable=False)]
    states = list(range(-9,0)) + list(range(1,10)); results = []
    for x in states:
        xi = int(np.sum(s_prime == x)); p = _safe_p(erfc(abs(xi - J)/math.sqrt(2.0*J*(4.0*abs(x)-2.0))))
        results.append(TestResult(f'Random Excursions Variant [state {x}]', p, _status_from_p(p, alpha), {'state': x, 'J': J, 'count': xi}, subtest=str(x)))
    return results

TEST_FUNCTIONS = {'Frequency': frequency_test, 'Block Frequency': block_frequency_test, 'Runs': runs_test, 'Longest Runs of Ones': longest_run_ones_test, 'Rank': rank_test, 'Spectral - Discrete Fourier Transform': spectral_test, 'Non-overlapping Template Matching': non_overlapping_template_test, 'Overlapping Template Matching': overlapping_template_test, 'Universal Statistical': universal_test, 'Linear Complexity': linear_complexity_test, 'Serial': serial_test, 'Approximate Entropy': approximate_entropy_test, 'Cumulative Sums': cumulative_sums_test, 'Random Excursions': random_excursions_test, 'Random Excursions Variant': random_excursions_variant_test}

def resolve_selected_tests(select_all_tests: bool, bitmask: str | None, explicit: Sequence[str] | None = None) -> list[str]:
    if explicit: return [t for t in TEST_ORDER if t in set(explicit)]
    if select_all_tests or not bitmask: return TEST_ORDER.copy()
    bitmask = ''.join(ch for ch in str(bitmask) if ch in '01').ljust(len(TEST_ORDER), '0')
    return [name for bit, name in zip(bitmask[:len(TEST_ORDER)], TEST_ORDER) if bit == '1']

def run_suite(input_file: Path, settings: dict[str, Any]) -> dict[str, Any]:
    alpha = float(settings.get('alpha', ALPHA_DEFAULT)); bits = bits_from_file(input_file); stream_len = int(settings.get('sequence_length_bits', 1000000)); auto = bool(settings.get('auto_bitstreams', True)); requested = int(settings.get('bitstreams', 0) or 0); selected = resolve_selected_tests(bool(settings.get('select_all_tests', True)), settings.get('test_selection'), settings.get('selected_tests')); streams = split_streams(bits, stream_len, requested=requested, auto=auto)
    payload = {'status': 'ok' if streams else 'unavailable', 'message': None if streams else 'Not enough bits to create any SP800-22 bitstream.', 'input_file': str(input_file), 'file_bits': int(bits.size), 'sequence_length_bits': stream_len, 'bitstreams_effective': len(streams), 'alpha': alpha, 'selected_tests': selected, 'test_selection': settings.get('test_selection', '111111111111111'), 'rows': [], 'per_stream': [], 'overall': {}, 'warnings': [], 'native_implementation': True}
    if not streams: return payload
    by_test = {}
    for idx, stream in enumerate(streams, start=1):
        stream_results = []
        for test_name in selected:
            func = TEST_FUNCTIONS[test_name]; kwargs = {}
            if test_name == 'Block Frequency': kwargs['M'] = int(settings.get('block_frequency_M', 128))
            elif test_name == 'Non-overlapping Template Matching': kwargs['m'] = int(settings.get('non_overlap_m', 9)); kwargs['template_limit'] = int(settings.get('non_overlap_template_limit', 16))
            elif test_name == 'Overlapping Template Matching': kwargs['m'] = int(settings.get('overlap_m', 9)); kwargs['M'] = int(settings.get('overlap_block_M', 1032)); kwargs['K'] = int(settings.get('overlap_K', 5))
            elif test_name == 'Linear Complexity': kwargs['M'] = int(settings.get('linear_complexity_M', 1000))
            elif test_name == 'Serial': kwargs['m'] = int(settings.get('serial_m', 3))
            elif test_name == 'Approximate Entropy': kwargs['m'] = int(settings.get('apen_m', 2))
            results = func(stream, alpha, **kwargs)
            for res in results:
                entry = {'stream_index': idx, 'test_name': res.test_name, 'subtest': res.subtest, 'pvalue': _safe_p(res.pvalue), 'passed': res.passed, 'applicable': res.applicable, 'details': res.details}
                stream_results.append(entry); by_test.setdefault(res.test_name, []).append(entry)
        payload['per_stream'].append({'stream_index': idx, 'results': stream_results})
    rows = []
    for report_idx, (test_name, entries) in enumerate(by_test.items(), start=1):
        applicable = [e for e in entries if e.get('applicable', True) and e.get('pvalue') is not None]; pvalues = [float(e['pvalue']) for e in applicable if e.get('pvalue') is not None]; bins, unif_p = _uniformity_bins(pvalues); applicable_count = len(applicable); passes = sum(1 for e in applicable if e.get('passed') is True); proportion = passes/applicable_count if applicable_count else None; min_rate = _min_pass_rate(alpha, applicable_count) if applicable_count else None
        rows.append({'report_index': report_idx, 'test_name': test_name, 'bins': bins, 'uniformity_pvalue': unif_p, 'proportion': proportion, 'sample_size': applicable_count, 'min_pass_rate': min_rate, 'proportion_ok': None if proportion is None or min_rate is None else (proportion >= min_rate), 'uniformity_ok': None if applicable_count < 55 or unif_p is None else (unif_p >= float(settings.get('uniformity_threshold', 0.0001))), 'pvalues_count': len(pvalues), 'passes': passes, 'fails': sum(1 for e in applicable if e.get('passed') is False), 'not_applicable': sum(1 for e in entries if not e.get('applicable', True) or e.get('pvalue') is None)})
    payload['rows'] = rows; sample_max = max((r['sample_size'] for r in rows), default=0)
    if sample_max < 10: payload['warnings'].append('Fewer than 10 sequences were processed; second-level SP800-22 proportion checks are not statistically meaningful.')
    elif sample_max < 55: payload['warnings'].append('Fewer than 55 sequences were processed; p-value uniformity checks should be treated as descriptive only.')
    payload['overall'] = {'sample_size': sample_max, 'rows_total': len(rows), 'proportion_min_pass_rate': _min_pass_rate(alpha, sample_max) if sample_max else None, 'proportion_rows_fail': sum(1 for r in rows if r.get('proportion_ok') is False), 'uniformity_rows_fail': sum(1 for r in rows if r.get('uniformity_ok') is False), 'rows_both_ok': sum(1 for r in rows if r.get('proportion_ok') is not False and r.get('uniformity_ok') is not False), 'rows_with_uniformity': sum(1 for r in rows if r.get('uniformity_ok') is not None), 'rows_with_proportion': sum(1 for r in rows if r.get('proportion_ok') is not None)}
    return payload
