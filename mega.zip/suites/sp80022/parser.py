from __future__ import annotations
import json
from pathlib import Path
from core.types import SuiteArtifacts, SuiteContext

def parse(ctx: SuiteContext, artifacts: SuiteArtifacts) -> dict:
    raw_json_path = Path(artifacts.raw_output) if artifacts.raw_output else None
    if not raw_json_path or not raw_json_path.exists():
        return {'status': 'unavailable', 'message': 'Native SP800-22 runner did not produce JSON output.', 'rows': [], 'overall': {}, 'warnings': []}
    return json.loads(raw_json_path.read_text(encoding='utf-8'))
