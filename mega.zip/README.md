# Megatool Modular Integrated Scaffold

This scaffold integrates a modular pipeline for entropy assessment and PDF reporting.

## What is integrated

- `compression` plugin computes a compression sanity check with standard Python compressors
- `visuals` plugin generates visual inspection charts for the input file
- `dieharder` plugin calls `scripts/dieharder/dieharder_run_tests.sh`
- `sp80090b` plugin calls `scripts/sp80090b/run_sp80090b.sh`
- `sp80022` plugin automates the NIST STS `assess` executable in file-input mode and parses `finalAnalysisReport.txt`
- parsed outputs are stored as JSON in `results/parsed`
- normalized outputs are stored in `results/normalized`
- the final PDF is generated in `results/reports`

## Project layout

```text
megatool_modular_integrated/
├── configs/
├── core/
├── report/
│   └── charts/
├── results/
├── scripts/
│   ├── dieharder/
│   ├── sp80022/
│   ├── sp80090b/
│   ├── run_full_assessment.py
│   └── run_full_assessment.sh
├── suites/
│   ├── compression/
│   ├── dieharder/
│   ├── sp80022/
│   ├── sp80090b/
│   ├── visuals/
│   └── lyapunov/
└── tools/
```

## Requirements

- Python 3.10+
- `reportlab`
- `PyYAML`
- `matplotlib`
- `dieharder` available in `PATH`
- compiled `ea_non_iid` binary from SP800-90B
- compiled `assess` executable from NIST SP800-22 STS if you want the SP800-22 suite to run

## Default binary paths

SP800-90B:

```text
./tools/SP800-90B_EntropyAssessment/cpp/ea_non_iid
```

SP800-22 STS:

```text
./tools/sts/sts/assess
```

The STS work directory is expected at:

```text
./tools/sts/sts
```

The SP800-22 wrapper copies the input file into `tools/sts/sts/data/` and collects the generated `experiments/AlgorithmTesting/finalAnalysisReport.txt`.

## Running the full pipeline

```bash
./scripts/run_full_assessment.sh --input /absolute/path/to/input.bin --bits 8
```

This executes:

1. compression sanity check
2. visual inspection suite
3. dieharder suite
4. SP800-90B non-IID suite
5. SP800-22 STS suite
6. parsing and normalization
7. final PDF generation

## SP800-22 notes

The SP800-22 suite uses the `assess <sequenceLength>` workflow described by NIST. The automation feeds the interactive prompts in file-input mode, selects either all 15 tests or a configured subset, computes the number of bitstreams from the input file when `auto_bitstreams: true`, and then parses the final analysis report.

Main settings are in:

```text
configs/suites/sp80022.yaml
```

Important knobs:

- `sequence_length_bits`
- `auto_bitstreams`
- `bitstreams`
- `select_all_tests`
- `test_selection`
- `input_format`
- `alpha`
- `uniformity_threshold`

If `assess` is missing, the pipeline does not crash. Instead, the SP800-22 section in the report is marked as unavailable.

## Current status

- `compression`: integrated and functional
- `visuals`: integrated and functional
- `dieharder`: integrated and functional
- `sp80090b`: integrated and functional
- `sp80022`: integrated and functional when `assess` is installed
- `lyapunov`: placeholder plugin

## Adding a new suite

Each suite keeps the same interface:

- `runner.py`
- `parser.py`
- `normalizer.py`
- config file in `configs/suites/`

Then enable it in `configs/pipeline.yaml`.


## Native SP800-22

The SP800-22 suite no longer depends on the legacy  executable. It runs a native Python implementation that computes first-level p-values per bitstream and aggregates second-level proportion and uniformity summaries across bitstreams.
