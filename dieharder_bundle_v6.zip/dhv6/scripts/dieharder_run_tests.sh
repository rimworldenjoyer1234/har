#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./common.sh
source "$SCRIPT_DIR/common.sh"
# shellcheck source=./dieharder_profiles.sh
source "$SCRIPT_DIR/dieharder_profiles.sh"

usage() {
  cat <<USAGE
Usage:
  $(basename "$0") --file PATH (--tests 0,10,11 | --all) [options]

Options:
  --file PATH              Input binary file
  --tests LIST             Comma-separated list of test IDs
  --all                    Run all enabled tests in the profile table
  --results-dir PATH       Results directory (default: ./results)
  --csv PATH               Aggregate CSV output path
  --safety FLOAT           Fraction of file allowed per test (default: 0.85)
  --fudge FLOAT            Conservative multiplier for byte estimates (default: 1.15)
  --psamples N             Preferred maximum -p value
  --ntuple N               Override -n where supported
  --generator ID           Dieharder generator (default: 201 for raw binary file)
  --verbose                Print a per-test assessment summary
  --dry-run                Print commands only
USAGE
}

require_cmd dieharder

FILE=""
TESTS=""
RUN_ALL=0
RESULTS_DIR="$RESULTS_DIR_DEFAULT"
CSV_PATH=""
SAFETY="0.85"
FUDGE="1.15"
USER_P=""
USER_N=""
GENERATOR="201"
VERBOSE=0
DRY_RUN=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --file) FILE="$2"; shift 2 ;;
    --tests) TESTS="$2"; shift 2 ;;
    --all) RUN_ALL=1; shift ;;
    --results-dir) RESULTS_DIR="$2"; shift 2 ;;
    --csv) CSV_PATH="$2"; shift 2 ;;
    --safety) SAFETY="$2"; shift 2 ;;
    --fudge) FUDGE="$2"; shift 2 ;;
    --psamples) USER_P="$2"; shift 2 ;;
    --ntuple) USER_N="$2"; shift 2 ;;
    --generator) GENERATOR="$2"; shift 2 ;;
    --verbose) VERBOSE=1; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) fail "Unknown option: $1" ;;
  esac
done

[[ -n "$FILE" ]] || fail "--file is required"
[[ -f "$FILE" ]] || fail "Input file not found: $FILE"
if [[ $RUN_ALL -ne 1 && -z "$TESTS" ]]; then
  fail "Use --tests or --all"
fi
if [[ $RUN_ALL -eq 1 && -n "$TESTS" ]]; then
  fail "Use either --tests or --all, not both"
fi

FILE="$(abs_path "$FILE")"
mkdir -p "$RESULTS_DIR/logs" "$RESULTS_DIR/csv"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
RUN_LOG="$RESULTS_DIR/logs/run_${TIMESTAMP}.log"
SUMMARY_CSV="${CSV_PATH:-$RESULTS_DIR/dieharder_summary_${TIMESTAMP}.csv}"
DIEHARDER_COMBINED_CSV="$RESULTS_DIR/csv/dieharder_output_${TIMESTAMP}.csv"

if [[ $RUN_ALL -eq 1 ]]; then
  mapfile -t TEST_ARRAY < <(
    for test_id in "${!DH_NAME[@]}"; do
      if [[ "${DH_ENABLED[$test_id]:-0}" == "1" && "${DH_MODE[$test_id]:-skip}" != "skip" ]]; then
        printf '%s\n' "$test_id"
      fi
    done | sort -n
  )
else
  mapfile -t TEST_ARRAY < <(split_csv_list "$TESTS")
fi

printf 'run_id,test_id,test_name,file,file_size_bytes,usable_bytes,mode,p_policy,formula,unit_bytes,adj_unit_bytes,bpt,t,p,n,status,overall_assessment,assessment_rows,passed_rows,weak_rows,failed_rows,min_p,max_p,rewind_flag,rewind_patterns,reliability_note,reason,log_path,raw_csv_path,command\n' > "$SUMMARY_CSV"
: > "$DIEHARDER_COMBINED_CSV"

echo "[INFO] Run log: $RUN_LOG" | tee -a "$RUN_LOG"
echo "[INFO] Summary CSV: $SUMMARY_CSV" | tee -a "$RUN_LOG"
echo "[INFO] Dieharder CSV: $DIEHARDER_COMBINED_CSV" | tee -a "$RUN_LOG"

append_dieharder_csv() {
  local src="$1"
  if [[ ! -s "$src" ]]; then
    return 0
  fi
  if [[ ! -s "$DIEHARDER_COMBINED_CSV" ]]; then
    grep -v '^#' "$src" | sed '/^$/d' > "$DIEHARDER_COMBINED_CSV" || true
  else
    grep -v '^#' "$src" | sed '/^$/d' | tail -n +2 >> "$DIEHARDER_COMBINED_CSV" || true
  fi
}

TOTAL_OK=0
TOTAL_FAILED=0
TOTAL_SKIPPED=0
TOTAL_WEAK=0
TOTAL_PASSED=0

for test_id in "${TEST_ARRAY[@]}"; do
  [[ -n "$test_id" ]] || continue

  CALC_CMD=("$SCRIPT_DIR/dieharder_calc_flags.sh" --file "$FILE" --test "$test_id" --safety "$SAFETY" --fudge "$FUDGE" --format sh)
  [[ -n "$USER_P" ]] && CALC_CMD+=(--psamples "$USER_P")
  [[ -n "$USER_N" ]] && CALC_CMD+=(--ntuple "$USER_N")

  eval "$(${CALC_CMD[@]})"

  TEST_LOG="$RESULTS_DIR/logs/test_${TEST_ID}_${TIMESTAMP}.log"
  RAW_CSV="$RESULTS_DIR/csv/test_${TEST_ID}_${TIMESTAMP}.csv"
  OVERALL_ASSESSMENT=""
  ASSESS_ROWS="0"
  PASSED_ROWS="0"
  WEAK_ROWS="0"
  FAILED_ROWS="0"
  MIN_P=""
  MAX_P=""
  REWIND_FLAG="NONE"
  REWIND_PATTERNS=""
  RELIABILITY_NOTE="none"

  if [[ "$ENABLED" != "1" ]]; then
    echo "[WARN] Skipping test $TEST_ID ($TEST_NAME): $REASON" | tee -a "$RUN_LOG"
    TOTAL_SKIPPED=$((TOTAL_SKIPPED + 1))
    printf '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n' \
      "$(csv_escape "$TIMESTAMP")" \
      "$(csv_escape "$TEST_ID")" \
      "$(csv_escape "$TEST_NAME")" \
      "$(csv_escape "$FILE")" \
      "$(csv_escape "$FILE_SIZE_BYTES")" \
      "$(csv_escape "$USABLE_BYTES")" \
      "$(csv_escape "$MODE")" \
      "$(csv_escape "$P_POLICY")" \
      "$(csv_escape "$FORMULA")" \
      "$(csv_escape "$UNIT_BYTES")" \
      "$(csv_escape "$ADJ_UNIT_BYTES")" \
      "$(csv_escape "${BPT:-}")" \
      "$(csv_escape "$T")" \
      "$(csv_escape "$P")" \
      "$(csv_escape "$N")" \
      '"SKIPPED"' \
      '"SKIPPED"' \
      '"0"' \
      '"0"' \
      '"0"' \
      '"0"' \
      '""' \
      '""' \
      '"NONE"' \
      '""' \
      '"skipped_by_calculator"' \
      "$(csv_escape "$REASON")" \
      "$(csv_escape "$TEST_LOG")" \
      "$(csv_escape "$RAW_CSV")" \
      '""' >> "$SUMMARY_CSV"
    continue
  fi

  OUTPUT_FLAGS=(-c , -D header -D show_num -D test_name -D ntuple -D tsamples -D psamples -D pvalues -D assessment)
  CMD=(dieharder -g "$GENERATOR" -f "$FILE")
  # shellcheck disable=SC2206
  FLAG_WORDS=($FLAGS)
  CMD+=("${FLAG_WORDS[@]}" "${OUTPUT_FLAGS[@]}")

  echo "[INFO] Running test $TEST_ID ($TEST_NAME): ${CMD[*]}" | tee -a "$RUN_LOG"

  if [[ $DRY_RUN -eq 1 ]]; then
    STATUS="DRY_RUN"
    OVERALL_ASSESSMENT="DRY_RUN"
    : > "$TEST_LOG"
    : > "$RAW_CSV"
  else
    set +e
    "${CMD[@]}" > "$RAW_CSV" 2> "$TEST_LOG"
    rc=$?
    set -e
    if [[ $rc -eq 0 ]]; then
      STATUS="OK"
      TOTAL_OK=$((TOTAL_OK + 1))
    else
      STATUS="FAILED"
      TOTAL_FAILED=$((TOTAL_FAILED + 1))
      echo "[ERROR] dieharder exited with code $rc for test $TEST_ID" | tee -a "$RUN_LOG"
    fi

    append_dieharder_csv "$RAW_CSV"

    if [[ -s "$RAW_CSV" ]]; then
      eval "$(dieharder_assessment_summary "$RAW_CSV")"
      OVERALL_ASSESSMENT="$OVERALL"
      ASSESS_ROWS="$ROWS"
      PASSED_ROWS="$PASSED"
      WEAK_ROWS="$WEAK"
      FAILED_ROWS="$FAILED"
      MIN_P="$MIN_P"
      MAX_P="$MAX_P"
    fi

    eval "$(dieharder_detect_rewind "$RAW_CSV" "$TEST_LOG")"
    RELIABILITY_NOTE="$(dieharder_reliability_note "$REWIND_FLAG" "$STATUS" "$OVERALL_ASSESSMENT" "$ASSESS_ROWS" "$RAW_CSV" "$TEST_LOG")"

    if [[ -s "$RAW_CSV" ]]; then
      if [[ "$OVERALL_ASSESSMENT" == "PASSED" ]]; then
        TOTAL_PASSED=$((TOTAL_PASSED + 1))
      elif [[ "$OVERALL_ASSESSMENT" == "WEAK" ]]; then
        TOTAL_WEAK=$((TOTAL_WEAK + 1))
      fi

      if [[ $VERBOSE -eq 1 ]]; then
        echo "[RESULT] Test $TEST_ID ($TEST_NAME): $OVERALL_ASSESSMENT | rows=$ASSESS_ROWS pass=$PASSED_ROWS weak=$WEAK_ROWS fail=$FAILED_ROWS pmin=$MIN_P pmax=$MAX_P rewind=$REWIND_FLAG note=$RELIABILITY_NOTE" | tee -a "$RUN_LOG"
      fi
    else
      OVERALL_ASSESSMENT="NO_DATA"
      eval "$(dieharder_detect_rewind "$RAW_CSV" "$TEST_LOG")"
      RELIABILITY_NOTE="$(dieharder_reliability_note "$REWIND_FLAG" "$STATUS" "$OVERALL_ASSESSMENT" "$ASSESS_ROWS" "$RAW_CSV" "$TEST_LOG")"
      if [[ $VERBOSE -eq 1 ]]; then
        echo "[RESULT] Test $TEST_ID ($TEST_NAME): NO_DATA | rewind=$REWIND_FLAG note=$RELIABILITY_NOTE" | tee -a "$RUN_LOG"
      fi
    fi
  fi

  printf '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n' \
    "$(csv_escape "$TIMESTAMP")" \
    "$(csv_escape "$TEST_ID")" \
    "$(csv_escape "$TEST_NAME")" \
    "$(csv_escape "$FILE")" \
    "$(csv_escape "$FILE_SIZE_BYTES")" \
    "$(csv_escape "$USABLE_BYTES")" \
    "$(csv_escape "$MODE")" \
    "$(csv_escape "$P_POLICY")" \
    "$(csv_escape "$FORMULA")" \
    "$(csv_escape "$UNIT_BYTES")" \
    "$(csv_escape "$ADJ_UNIT_BYTES")" \
    "$(csv_escape "${BPT:-}")" \
    "$(csv_escape "$T")" \
    "$(csv_escape "$P")" \
    "$(csv_escape "$N")" \
    "$(csv_escape "$STATUS")" \
    "$(csv_escape "$OVERALL_ASSESSMENT")" \
    "$(csv_escape "$ASSESS_ROWS")" \
    "$(csv_escape "$PASSED_ROWS")" \
    "$(csv_escape "$WEAK_ROWS")" \
    "$(csv_escape "$FAILED_ROWS")" \
    "$(csv_escape "$MIN_P")" \
    "$(csv_escape "$MAX_P")" \
    "$(csv_escape "$REWIND_FLAG")" \
    "$(csv_escape "$REWIND_PATTERNS")" \
    "$(csv_escape "$RELIABILITY_NOTE")" \
    "$(csv_escape "$REASON")" \
    "$(csv_escape "$TEST_LOG")" \
    "$(csv_escape "$RAW_CSV")" \
    "$(csv_escape "${CMD[*]}")" >> "$SUMMARY_CSV"
done

echo "[INFO] Completed. status_ok=$TOTAL_OK status_failed=$TOTAL_FAILED skipped=$TOTAL_SKIPPED assessments_passed=$TOTAL_PASSED assessments_weak=$TOTAL_WEAK" | tee -a "$RUN_LOG"
