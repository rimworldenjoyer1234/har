#!/usr/bin/env bash
# Per-test profiles for file-driven dieharder runs.
#
# Goal:
#   avoid file rewind as much as possible when testing raw binary files.
#
# Strategy:
#   - for variable-size tests, keep -p modest and let -t grow with file size
#   - for fixed-size tests, compute only -p
#   - where the source code makes the byte cost clear, encode that directly
#   - where it does not, keep the profile conservative and explicit

set -Eeuo pipefail

declare -Ag DH_NAME=()
declare -Ag DH_MODE=()
declare -Ag DH_UNIT_BYTES=()
declare -Ag DH_DEFAULT_P=()
declare -Ag DH_MIN_P=()
declare -Ag DH_MIN_T=()
declare -Ag DH_MAX_T=()
declare -Ag DH_DEFAULT_T=()
declare -Ag DH_DEFAULT_N=()
declare -Ag DH_ENABLED=()
declare -Ag DH_EXTRA_ARGS=()
declare -Ag DH_FORMULA=()
declare -Ag DH_P_POLICY=()

# mode:
#   tp   -> compute -t and -p
#   p    -> compute only -p, omit -t
#   tpn  -> compute -t, -p and set -n
#   skip -> skip test
#
# formula:
#   approx              -> estimated bytes-per-tsample via UNIT_BYTES
#   exact_const         -> exact fixed bytes-per-tsample
#   rgb_bitdist         -> bytes-per-tsample = 64 * ntuple / 8
#   rgb_tuple_uints     -> bytes-per-tsample = 4 * ntuple
#   rgb_lagged_sum      -> bytes-per-tsample = 4 * (ntuple + 1)
#   dab_dct             -> bytes-per-tsample = 4 * ntuple
#   dab_filltree_emp    -> empirical bytes-per-tsample from published default sizes
#   dab_filltree2_emp   -> empirical bytes-per-tsample from published default sizes
#
# p policy:
#   min      -> prefer a small but useful -p, maximize -t with file size
#   default  -> prefer the profile default -p

# -----------------------------------------------------------------------------
# Diehard classic
# Source-derived where possible.
# -----------------------------------------------------------------------------
# Birthdays: 512 samples per tsample, one 24-bit draw each; implementation draws
# uint-sized values, so ~512 * 4 = 2048 bytes / tsample.
DH_NAME[0]='Diehard Birthdays Test';                      DH_MODE[0]='tp';  DH_UNIT_BYTES[0]=2048;    DH_DEFAULT_P[0]=100; DH_MIN_P[0]=7; DH_MIN_T[0]=1; DH_MAX_T[0]=100;     DH_DEFAULT_T[0]=100;     DH_DEFAULT_N[0]=''; DH_ENABLED[0]=1; DH_EXTRA_ARGS[0]=''; DH_FORMULA[0]='approx';          DH_P_POLICY[0]='min'
# OPERM5: with overlap enabled (dieharder default), one new uint per tsample
# after the initial warm-up. Cap at the classic 1,000,000 sample scale.
DH_NAME[1]='Diehard OPERM5 Test';                         DH_MODE[1]='tp';  DH_UNIT_BYTES[1]=4;       DH_DEFAULT_P[1]=100; DH_MIN_P[1]=7; DH_MIN_T[1]=1; DH_MAX_T[1]=1000000; DH_DEFAULT_T[1]=1000000; DH_DEFAULT_N[1]=''; DH_ENABLED[1]=1; DH_EXTRA_ARGS[1]=''; DH_FORMULA[1]='approx';          DH_P_POLICY[1]='min'
# 32x32 rank: each matrix uses 32 uints => 128 bytes / tsample; default scale 40000.
DH_NAME[2]='Diehard 32x32 Binary Rank Test';             DH_MODE[2]='tp';  DH_UNIT_BYTES[2]=128;     DH_DEFAULT_P[2]=100; DH_MIN_P[2]=7; DH_MIN_T[2]=1; DH_MAX_T[2]=40000;   DH_DEFAULT_T[2]=40000;   DH_DEFAULT_N[2]=''; DH_ENABLED[2]=1; DH_EXTRA_ARGS[2]=''; DH_FORMULA[2]='approx';          DH_P_POLICY[2]='min'
# 6x8 rank: six uints per matrix => 24 bytes / tsample; default scale 100000.
DH_NAME[3]='Diehard 6x8 Binary Rank Test';               DH_MODE[3]='tp';  DH_UNIT_BYTES[3]=24;      DH_DEFAULT_P[3]=100; DH_MIN_P[3]=7; DH_MIN_T[3]=1; DH_MAX_T[3]=100000;  DH_DEFAULT_T[3]=100000;  DH_DEFAULT_N[3]=''; DH_ENABLED[3]=1; DH_EXTRA_ARGS[3]=''; DH_FORMULA[3]='approx';          DH_P_POLICY[3]='min'
# Bitstream: implementation fills BS_OVERLAP=262146 uints per p-value.
DH_NAME[4]='Diehard Bitstream Test';                     DH_MODE[4]='p';   DH_UNIT_BYTES[4]=1048584; DH_DEFAULT_P[4]=100; DH_MIN_P[4]=1; DH_MIN_T[4]=0; DH_MAX_T[4]=0;       DH_DEFAULT_T[4]=0;       DH_DEFAULT_N[4]=''; DH_ENABLED[4]=1; DH_EXTRA_ARGS[4]=''; DH_FORMULA[4]='approx';          DH_P_POLICY[4]='default'
# OPSO/OQSO/DNA have fixed 2^21-word style runs; tsamples cannot be varied.
DH_NAME[5]='Diehard OPSO Test';                          DH_MODE[5]='p';   DH_UNIT_BYTES[5]=8388608; DH_DEFAULT_P[5]=100; DH_MIN_P[5]=1; DH_MIN_T[5]=0; DH_MAX_T[5]=0;       DH_DEFAULT_T[5]=0;       DH_DEFAULT_N[5]=''; DH_ENABLED[5]=1; DH_EXTRA_ARGS[5]=''; DH_FORMULA[5]='approx';          DH_P_POLICY[5]='default'
DH_NAME[6]='Diehard OQSO Test';                          DH_MODE[6]='p';   DH_UNIT_BYTES[6]=6291456; DH_DEFAULT_P[6]=100; DH_MIN_P[6]=1; DH_MIN_T[6]=0; DH_MAX_T[6]=0;       DH_DEFAULT_T[6]=0;       DH_DEFAULT_N[6]=''; DH_ENABLED[6]=1; DH_EXTRA_ARGS[6]=''; DH_FORMULA[6]='approx';          DH_P_POLICY[6]='default'
DH_NAME[7]='Diehard DNA Test';                           DH_MODE[7]='p';   DH_UNIT_BYTES[7]=3145728; DH_DEFAULT_P[7]=100; DH_MIN_P[7]=1; DH_MIN_T[7]=0; DH_MAX_T[7]=0;       DH_DEFAULT_T[7]=0;       DH_DEFAULT_N[7]=''; DH_ENABLED[7]=1; DH_EXTRA_ARGS[7]=''; DH_FORMULA[7]='approx';          DH_P_POLICY[7]='default'
# Count-the-1s stream: overlap mode advances one byte per tsample on average.
DH_NAME[8]='Diehard Count the 1s (stream) Test';         DH_MODE[8]='tp';  DH_UNIT_BYTES[8]=1;       DH_DEFAULT_P[8]=100; DH_MIN_P[8]=7; DH_MIN_T[8]=1; DH_MAX_T[8]=256000;  DH_DEFAULT_T[8]=256000;  DH_DEFAULT_N[8]=''; DH_ENABLED[8]=1; DH_EXTRA_ARGS[8]=''; DH_FORMULA[8]='approx';          DH_P_POLICY[8]='min'
# Count-the-1s byte: one selected byte from each uint => ~4 bytes / tsample.
DH_NAME[9]='Diehard Count the 1s Test (byte)';           DH_MODE[9]='tp';  DH_UNIT_BYTES[9]=4;       DH_DEFAULT_P[9]=100; DH_MIN_P[9]=7; DH_MIN_T[9]=1; DH_MAX_T[9]=256000;  DH_DEFAULT_T[9]=256000;  DH_DEFAULT_N[9]=''; DH_ENABLED[9]=1; DH_EXTRA_ARGS[9]=''; DH_FORMULA[9]='approx';          DH_P_POLICY[9]='min'

# Parking lot / distance family: do not emit -t here because dieharder ignores
# it in these legacy forms. The units below are per p-value run.
# Parking lot: 12000 attempts, x/y coordinates each time => about 12000*2*4 bytes.
DH_NAME[10]='Diehard Parking Lot Test';                  DH_MODE[10]='p';  DH_UNIT_BYTES[10]=96000;  DH_DEFAULT_P[10]=100; DH_MIN_P[10]=7; DH_MIN_T[10]=0; DH_MAX_T[10]=0;      DH_DEFAULT_T[10]=0;      DH_DEFAULT_N[10]=''; DH_ENABLED[10]=1; DH_EXTRA_ARGS[10]=''; DH_FORMULA[10]='approx';         DH_P_POLICY[10]='default'
# 2d circle: 8000 points in 2d => about 8000*2*4 bytes.
DH_NAME[11]='Diehard Minimum Distance (2d Circle) Test'; DH_MODE[11]='p';  DH_UNIT_BYTES[11]=64000;  DH_DEFAULT_P[11]=100; DH_MIN_P[11]=1; DH_MIN_T[11]=0; DH_MAX_T[11]=0;      DH_DEFAULT_T[11]=0;      DH_DEFAULT_N[11]=''; DH_ENABLED[11]=1; DH_EXTRA_ARGS[11]=''; DH_FORMULA[11]='approx';         DH_P_POLICY[11]='default'
# 3d sphere: 8000 points in 3d => about 8000*3*4 bytes.
DH_NAME[12]='Diehard 3d Sphere (Minimum Distance) Test'; DH_MODE[12]='p';  DH_UNIT_BYTES[12]=96000;  DH_DEFAULT_P[12]=100; DH_MIN_P[12]=1; DH_MIN_T[12]=0; DH_MAX_T[12]=0;      DH_DEFAULT_T[12]=0;      DH_DEFAULT_N[12]=''; DH_ENABLED[12]=1; DH_EXTRA_ARGS[12]=''; DH_FORMULA[12]='approx';         DH_P_POLICY[12]='default'

# Squeeze: source-derived expected loop count is about 23 draws per tsample.
DH_NAME[13]='Diehard Squeeze Test';                      DH_MODE[13]='tp';  DH_UNIT_BYTES[13]=96;     DH_DEFAULT_P[13]=100; DH_MIN_P[13]=7; DH_MIN_T[13]=1; DH_MAX_T[13]=100000;  DH_DEFAULT_T[13]=100000;  DH_DEFAULT_N[13]=''; DH_ENABLED[13]=1; DH_EXTRA_ARGS[13]=''; DH_FORMULA[13]='approx';         DH_P_POLICY[13]='min'
DH_NAME[14]='Diehard Sums Test';                         DH_MODE[14]='skip'; DH_UNIT_BYTES[14]=0;      DH_DEFAULT_P[14]=0;  DH_MIN_P[14]=0; DH_MIN_T[14]=0; DH_MAX_T[14]=0;       DH_DEFAULT_T[14]=0;      DH_DEFAULT_N[14]=''; DH_ENABLED[14]=0; DH_EXTRA_ARGS[14]=''; DH_FORMULA[14]='approx';         DH_P_POLICY[14]='default'
# Runs: one uint per tsample; cap at default-like 100000.
DH_NAME[15]='Diehard Runs Test';                         DH_MODE[15]='tp';  DH_UNIT_BYTES[15]=4;      DH_DEFAULT_P[15]=100; DH_MIN_P[15]=7; DH_MIN_T[15]=1; DH_MAX_T[15]=100000;  DH_DEFAULT_T[15]=100000;  DH_DEFAULT_N[15]=''; DH_ENABLED[15]=1; DH_EXTRA_ARGS[15]=''; DH_FORMULA[15]='approx';         DH_P_POLICY[15]='min'
# Craps: variable rolls per game; keep conservative average at ~24 bytes / game.
DH_NAME[16]='Diehard Craps Test';                        DH_MODE[16]='tp';  DH_UNIT_BYTES[16]=27;     DH_DEFAULT_P[16]=100; DH_MIN_P[16]=7; DH_MIN_T[16]=1; DH_MAX_T[16]=200000;  DH_DEFAULT_T[16]=200000;  DH_DEFAULT_N[16]=''; DH_ENABLED[16]=1; DH_EXTRA_ARGS[16]=''; DH_FORMULA[16]='approx';         DH_P_POLICY[16]='min'
# GCD: two uints per tsample.
DH_NAME[17]='Marsaglia and Tsang GCD Test';              DH_MODE[17]='tp';  DH_UNIT_BYTES[17]=8;      DH_DEFAULT_P[17]=100; DH_MIN_P[17]=7; DH_MIN_T[17]=1; DH_MAX_T[17]=100000;  DH_DEFAULT_T[17]=100000;  DH_DEFAULT_N[17]=''; DH_ENABLED[17]=1; DH_EXTRA_ARGS[17]=''; DH_FORMULA[17]='approx';         DH_P_POLICY[17]='min'

# -----------------------------------------------------------------------------
# STS
# -----------------------------------------------------------------------------
# Dieharder implementations consume tsamples uints here, so scale -t.
DH_NAME[100]='STS Monobit Test';                         DH_MODE[100]='tp';  DH_UNIT_BYTES[100]=4;     DH_DEFAULT_P[100]=100; DH_MIN_P[100]=7; DH_MIN_T[100]=1; DH_MAX_T[100]=100000; DH_DEFAULT_T[100]=100000; DH_DEFAULT_N[100]=''; DH_ENABLED[100]=1; DH_EXTRA_ARGS[100]=''; DH_FORMULA[100]='approx';        DH_P_POLICY[100]='min'
DH_NAME[101]='STS Runs Test';                            DH_MODE[101]='tp';  DH_UNIT_BYTES[101]=4;     DH_DEFAULT_P[101]=100; DH_MIN_P[101]=7; DH_MIN_T[101]=1; DH_MAX_T[101]=100000; DH_DEFAULT_T[101]=100000; DH_DEFAULT_N[101]=''; DH_ENABLED[101]=1; DH_EXTRA_ARGS[101]=''; DH_FORMULA[101]='approx';        DH_P_POLICY[101]='min'
# STS Serial: current dieharder code consumes tsamples uints and uses ntuple.
DH_NAME[102]='STS Serial Test (Generalized)';            DH_MODE[102]='tpn'; DH_UNIT_BYTES[102]=4;     DH_DEFAULT_P[102]=100; DH_MIN_P[102]=7; DH_MIN_T[102]=1; DH_MAX_T[102]=100000; DH_DEFAULT_T[102]=100000; DH_DEFAULT_N[102]=16; DH_ENABLED[102]=1; DH_EXTRA_ARGS[102]=''; DH_FORMULA[102]='approx';        DH_P_POLICY[102]='min'

# -----------------------------------------------------------------------------
# RGB / DAB
# -----------------------------------------------------------------------------
DH_NAME[200]='RGB Bit Distribution Test';                DH_MODE[200]='tpn'; DH_UNIT_BYTES[200]=0;     DH_DEFAULT_P[200]=100; DH_MIN_P[200]=7; DH_MIN_T[200]=1; DH_MAX_T[200]=100000; DH_DEFAULT_T[200]=100000; DH_DEFAULT_N[200]=12; DH_ENABLED[200]=1; DH_EXTRA_ARGS[200]=''; DH_FORMULA[200]='rgb_bitdist';    DH_P_POLICY[200]='min'
# Generalized minimum distance draws ntuple coordinates per point.
DH_NAME[201]='RGB Generalized Minimum Distance Test';    DH_MODE[201]='tpn'; DH_UNIT_BYTES[201]=0;     DH_DEFAULT_P[201]=100; DH_MIN_P[201]=7; DH_MIN_T[201]=1; DH_MAX_T[201]=8000;   DH_DEFAULT_T[201]=8000;   DH_DEFAULT_N[201]=2;  DH_ENABLED[201]=1; DH_EXTRA_ARGS[201]=''; DH_FORMULA[201]='rgb_tuple_uints'; DH_P_POLICY[201]='min'
# RGB permutations: one uint per tuple entry.
DH_NAME[202]='RGB Permutations Test';                    DH_MODE[202]='tpn'; DH_UNIT_BYTES[202]=0;     DH_DEFAULT_P[202]=100; DH_MIN_P[202]=7; DH_MIN_T[202]=1; DH_MAX_T[202]=100000; DH_DEFAULT_T[202]=100000; DH_DEFAULT_N[202]=5;  DH_ENABLED[202]=1; DH_EXTRA_ARGS[202]=''; DH_FORMULA[202]='rgb_tuple_uints'; DH_P_POLICY[202]='min'
# Lagged Sum left conservative for now.
DH_NAME[203]='RGB Lagged Sum Test';                      DH_MODE[203]='tpn'; DH_UNIT_BYTES[203]=0;       DH_DEFAULT_P[203]=100; DH_MIN_P[203]=7; DH_MIN_T[203]=1; DH_MAX_T[203]=1000000; DH_DEFAULT_T[203]=1000000; DH_DEFAULT_N[203]=0;  DH_ENABLED[203]=1; DH_EXTRA_ARGS[203]=''; DH_FORMULA[203]='rgb_lagged_sum'; DH_P_POLICY[203]='min'
DH_NAME[204]='RGB Kolmogorov-Smirnov Test';              DH_MODE[204]='tp';  DH_UNIT_BYTES[204]=4;       DH_DEFAULT_P[204]=1000; DH_MIN_P[204]=7; DH_MIN_T[204]=1; DH_MAX_T[204]=10000;   DH_DEFAULT_T[204]=10000;  DH_DEFAULT_N[204]=''; DH_ENABLED[204]=1; DH_EXTRA_ARGS[204]=''; DH_FORMULA[204]='exact_const';   DH_P_POLICY[204]='min'
DH_NAME[205]='Byte Distribution';                        DH_MODE[205]='tp';  DH_UNIT_BYTES[205]=12;      DH_DEFAULT_P[205]=1;    DH_MIN_P[205]=1; DH_MIN_T[205]=1; DH_MAX_T[205]=51200000; DH_DEFAULT_T[205]=51200000; DH_DEFAULT_N[205]=''; DH_ENABLED[205]=1; DH_EXTRA_ARGS[205]=''; DH_FORMULA[205]='exact_const';   DH_P_POLICY[205]='default'
DH_NAME[206]='DAB DCT Test';                             DH_MODE[206]='tpn'; DH_UNIT_BYTES[206]=0;       DH_DEFAULT_P[206]=1;    DH_MIN_P[206]=1; DH_MIN_T[206]=1; DH_MAX_T[206]=50000;   DH_DEFAULT_T[206]=50000;  DH_DEFAULT_N[206]=256; DH_ENABLED[206]=1; DH_EXTRA_ARGS[206]=''; DH_FORMULA[206]='dab_dct';       DH_P_POLICY[206]='default'
DH_NAME[207]='DAB Fill Tree Test';                       DH_MODE[207]='tpn'; DH_UNIT_BYTES[207]=29;      DH_DEFAULT_P[207]=1;    DH_MIN_P[207]=1; DH_MIN_T[207]=1; DH_MAX_T[207]=15000000; DH_DEFAULT_T[207]=15000000; DH_DEFAULT_N[207]=32;  DH_ENABLED[207]=1; DH_EXTRA_ARGS[207]=''; DH_FORMULA[207]='dab_filltree_emp'; DH_P_POLICY[207]='default'
DH_NAME[208]='DAB Fill Tree 2 Test';                     DH_MODE[208]='tpn'; DH_UNIT_BYTES[208]=24;      DH_DEFAULT_P[208]=1;    DH_MIN_P[208]=1; DH_MIN_T[208]=1; DH_MAX_T[208]=5000000;  DH_DEFAULT_T[208]=5000000; DH_DEFAULT_N[208]=1;   DH_ENABLED[208]=1; DH_EXTRA_ARGS[208]=''; DH_FORMULA[208]='dab_filltree2_emp'; DH_P_POLICY[208]='default'
DH_NAME[209]='DAB Monobit 2 Test';                       DH_MODE[209]='tpn'; DH_UNIT_BYTES[209]=4;       DH_DEFAULT_P[209]=1;    DH_MIN_P[209]=1; DH_MIN_T[209]=1; DH_MAX_T[209]=65000000; DH_DEFAULT_T[209]=65000000; DH_DEFAULT_N[209]=12;  DH_ENABLED[209]=1; DH_EXTRA_ARGS[209]=''; DH_FORMULA[209]='exact_const';   DH_P_POLICY[209]='default'

profile_exists() {
  local test_id="$1"
  [[ -n "${DH_NAME[$test_id]:-}" ]]
}
