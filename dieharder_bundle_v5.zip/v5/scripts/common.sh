#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RESULTS_DIR_DEFAULT="$PROJECT_ROOT/results"
SCRIPTS_DIR_DEFAULT="$PROJECT_ROOT/scripts"

log() {
  local level="$1"; shift
  printf '[%s] %s\n' "$level" "$*" >&2
}

fail() {
  log ERROR "$*"
  exit 1
}

require_cmd() {
  local cmd="$1"
  command -v "$cmd" >/dev/null 2>&1 || fail "Required command not found: $cmd"
}

abs_path() {
  local p="$1"
  if [[ -d "$p" ]]; then
    (cd "$p" && pwd)
  else
    local dir base
    dir="$(dirname "$p")"
    base="$(basename "$p")"
    (cd "$dir" && printf '%s/%s\n' "$(pwd)" "$base")
  fi
}

file_size_bytes() {
  local file="$1"
  if stat --version >/dev/null 2>&1; then
    stat -c '%s' "$file"
  else
    stat -f '%z' "$file"
  fi
}

human_bytes() {
  local bytes="$1"
  awk -v b="$bytes" 'BEGIN {
    split("B KiB MiB GiB TiB", u, " ");
    i = 1;
    while (b >= 1024 && i < 5) { b /= 1024; i++ }
    printf "%.2f %s", b, u[i]
  }'
}

csv_escape() {
  local s="$1"
  s=${s//\"/\"\"}
  printf '"%s"' "$s"
}

join_by() {
  local delim="$1"; shift || true
  local out=""
  local first=1
  for item in "$@"; do
    if [[ $first -eq 1 ]]; then
      out="$item"
      first=0
    else
      out+="$delim$item"
    fi
  done
  printf '%s' "$out"
}

trim() {
  local s="$1"
  s="${s#${s%%[![:space:]]*}}"
  s="${s%${s##*[![:space:]]}}"
  printf '%s' "$s"
}

split_csv_list() {
  local input="$1"
  IFS=',' read -r -a _OUT <<< "$input"
  for i in "${!_OUT[@]}"; do
    _OUT[$i]="$(trim "${_OUT[$i]}")"
  done
  printf '%s\n' "${_OUT[@]}"
}

dieharder_assessment_summary() {
  local csv_file="$1"
  awk -F',' '
    function trim(s) { gsub(/^[[:space:]"]+|[[:space:]"]+$/, "", s); return s }
    BEGIN {
      rows = passed = weak = failed = other = 0;
      minp = 2; maxp = -1;
    }
    /^[[:space:]]*#/ || /^[[:space:]]*$/ { next }
    {
      last = trim($NF);
      if (tolower(last) ~ /assessment/) next;
      ptxt = trim($(NF-1));
      rows++;
      if (ptxt ~ /^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$/) {
        p = ptxt + 0;
        if (p < minp) minp = p;
        if (p > maxp) maxp = p;
      }
      low = tolower(last);
      if (low ~ /fail/) failed++;
      else if (low ~ /weak/) weak++;
      else if (low ~ /pass/) passed++;
      else other++;
    }
    END {
      overall = "UNKNOWN";
      if (rows == 0) overall = "NO_DATA";
      else if (failed > 0) overall = "FAILED";
      else if (weak > 0) overall = "WEAK";
      else if (passed > 0 && other == 0) overall = "PASSED";
      if (minp == 2) minp = "";
      if (maxp == -1) maxp = "";
      printf "OVERALL=%s\nROWS=%d\nPASSED=%d\nWEAK=%d\nFAILED=%d\nOTHER=%d\nMIN_P=%s\nMAX_P=%s\n", overall, rows, passed, weak, failed, other, minp, maxp;
    }
  ' "$csv_file"
}
