#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./common.sh
source "$SCRIPT_DIR/common.sh"
# shellcheck source=./dieharder_profiles.sh
source "$SCRIPT_DIR/dieharder_profiles.sh"

usage() {
  cat <<USAGE
Usage:
  $(basename "$0") --file PATH --test ID [options]

Options:
  --file PATH              Input binary file
  --test ID                Dieharder test id
  --format flags|sh        Output format (default: sh)
  --safety FLOAT           Fraction of file allowed for one test (default: 0.85)
  --fudge FLOAT            Conservative multiplier for byte estimates (default: 1.15)
  --psamples N             Override preferred -p
  --ntuple N               Override -n where supported
USAGE
}

FILE=""
TEST_ID=""
FORMAT="sh"
SAFETY="0.85"
FUDGE="1.15"
USER_P=""
USER_N=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --file) FILE="$2"; shift 2 ;;
    --test) TEST_ID="$2"; shift 2 ;;
    --format) FORMAT="$2"; shift 2 ;;
    --safety) SAFETY="$2"; shift 2 ;;
    --fudge) FUDGE="$2"; shift 2 ;;
    --psamples) USER_P="$2"; shift 2 ;;
    --ntuple) USER_N="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) fail "Unknown option: $1" ;;
  esac
done

[[ -n "$FILE" ]] || fail "--file is required"
[[ -f "$FILE" ]] || fail "Input file not found: $FILE"
[[ -n "$TEST_ID" ]] || fail "--test is required"
[[ "$FORMAT" == "flags" || "$FORMAT" == "sh" ]] || fail "--format must be flags or sh"
profile_exists "$TEST_ID" || fail "No profile for test id $TEST_ID"

FILE="$(abs_path "$FILE")"
FILE_SIZE_BYTES="$(file_size_bytes "$FILE")"
USABLE_BYTES="$(awk -v size="$FILE_SIZE_BYTES" -v safety="$SAFETY" 'BEGIN { printf "%d", size*safety }')"

NAME="${DH_NAME[$TEST_ID]}"
MODE="${DH_MODE[$TEST_ID]}"
UNIT_BYTES="${DH_UNIT_BYTES[$TEST_ID]}"
DEFAULT_P="${DH_DEFAULT_P[$TEST_ID]}"
MIN_P="${DH_MIN_P[$TEST_ID]}"
MIN_T="${DH_MIN_T[$TEST_ID]}"
MAX_T="${DH_MAX_T[$TEST_ID]}"
DEFAULT_T="${DH_DEFAULT_T[$TEST_ID]}"
DEFAULT_N="${DH_DEFAULT_N[$TEST_ID]}"
ENABLED="${DH_ENABLED[$TEST_ID]}"
EXTRA_ARGS="${DH_EXTRA_ARGS[$TEST_ID]}"
FORMULA="${DH_FORMULA[$TEST_ID]}"
P_POLICY="${DH_P_POLICY[$TEST_ID]:-default}"

ADJ_UNIT_BYTES="$(awk -v unit="$UNIT_BYTES" -v fudge="$FUDGE" 'BEGIN { if (unit <= 0) print 0; else printf "%d", unit*fudge }')"
ENABLED_OUT=1
REASON=""
T=""
P=""
N=""
FLAGS=""

bytes_per_tsample() {
  local test_id="$1"
  local n="$2"
  case "$test_id" in
    200)
      # rgb_bitdist: bsamples = 64 n-tuples per tsample, each n bits
      awk -v ntuple="$n" 'BEGIN { printf "%d", (64*ntuple)/8 }'
      ;;
    201|202)
      # rgb minimum distance / permutations: one uint per tuple entry
      awk -v ntuple="$n" 'BEGIN { printf "%d", 4*ntuple }'
      ;;
    203)
      # rgb lagged sum: published default sizes imply 4*(ntuple+1) bytes/tsample
      awk -v ntuple="$n" 'BEGIN { printf "%d", 4*(ntuple+1) }'
      ;;
    206)
      # dab dct: published default sizes imply 4*ntuple bytes/tsample
      awk -v ntuple="$n" 'BEGIN { printf "%d", 4*ntuple }'
      ;;
    207)
      # dab filltree: empirical profile from published default sizes
      printf '%s' "${DH_UNIT_BYTES[207]}"
      ;;
    208)
      # dab filltree2: empirical profile from published default sizes
      printf '%s' "${DH_UNIT_BYTES[208]}"
      ;;
    *)
      fail "No exact bytes_per_tsample formula for test $test_id"
      ;;
  esac
}

choose_preferred_p() {
  if [[ -n "$USER_P" ]]; then
    printf '%s' "$USER_P"
    return 0
  fi

  case "$P_POLICY" in
    min)
      printf '%s' "$MIN_P"
      ;;
    default|*)
      printf '%s' "$DEFAULT_P"
      ;;
  esac
}

if [[ "$ENABLED" != "1" || "$MODE" == "skip" ]]; then
  ENABLED_OUT=0
  REASON="test marked as skip"
else
  if [[ -n "$USER_N" ]]; then
    N="$USER_N"
  else
    N="$DEFAULT_N"
  fi

  case "$MODE" in
    tp|tpn)
      TARGET_P="$(choose_preferred_p)"
      if [[ "$TARGET_P" -lt 1 ]]; then
        TARGET_P=1
      fi

      if [[ "$FORMULA" == "rgb_bitdist" || "$FORMULA" == "rgb_tuple_uints" || "$FORMULA" == "rgb_lagged_sum" || "$FORMULA" == "dab_dct" || "$FORMULA" == "dab_filltree_emp" || "$FORMULA" == "dab_filltree2_emp" ]]; then
        if [[ -z "$N" ]]; then
          case "$TEST_ID" in
            200) N=12 ;;
            201) N=2 ;;
            202) N=5 ;;
          esac
        fi
        BPT="$(bytes_per_tsample "$TEST_ID" "$N")"
        T="$(awk -v usable="$USABLE_BYTES" -v bpt="$BPT" -v p="$TARGET_P" 'BEGIN { if (bpt*p <= 0) print 0; else printf "%d", usable/(bpt*p) }')"

        if [[ "$DEFAULT_T" -gt 0 && "$T" -gt "$DEFAULT_T" ]]; then
          T="$DEFAULT_T"
          P="$(awk -v usable="$USABLE_BYTES" -v bpt="$BPT" -v t="$T" -v defp="$DEFAULT_P" 'BEGIN { if (bpt*t <= 0) print 0; else { p=int(usable/(bpt*t)); if (p>defp) p=defp; print p } }')"
        else
          P="$TARGET_P"
        fi
      else
        T="$(awk -v usable="$USABLE_BYTES" -v unit="$ADJ_UNIT_BYTES" -v p="$TARGET_P" 'BEGIN { if (unit*p <= 0) print 0; else printf "%d", usable/(unit*p) }')"
        if [[ "$T" -gt "$MAX_T" ]]; then
          T="$MAX_T"
        fi

        if [[ "$DEFAULT_T" -gt 0 && "$T" -gt "$DEFAULT_T" ]]; then
          T="$DEFAULT_T"
          P="$(awk -v usable="$USABLE_BYTES" -v unit="$ADJ_UNIT_BYTES" -v t="$T" -v defp="$DEFAULT_P" 'BEGIN { if (unit*t <= 0) print 0; else { p=int(usable/(unit*t)); if (p>defp) p=defp; print p } }')"
        else
          P="$TARGET_P"
        fi
      fi

      if [[ "$P" -lt "$MIN_P" ]]; then
        P="$MIN_P"
      fi
      if [[ "$T" -lt "$MIN_T" ]]; then
        ENABLED_OUT=0
        REASON="file too small for requested test without forcing meaningless -t"
      fi
      ;;
    p)
      TARGET_P="$(choose_preferred_p)"
      if [[ "$TARGET_P" -lt "$MIN_P" ]]; then
        TARGET_P="$MIN_P"
      fi
      P="$(awk -v usable="$USABLE_BYTES" -v unit="$ADJ_UNIT_BYTES" -v target="$TARGET_P" 'BEGIN { if (unit <= 0) print 0; else { p=int(usable/unit); if (p>target) p=target; print p } }')"
      if [[ "$P" -lt 1 ]]; then
        ENABLED_OUT=0
        REASON="file too small for conservative estimate"
      fi
      ;;
    *)
      fail "Unsupported mode in profile: $MODE"
      ;;
  esac
fi

if [[ "$ENABLED_OUT" == "1" ]]; then
  case "$MODE" in
    tp)
      FLAGS="-d $TEST_ID -t $T -p $P"
      ;;
    tpn)
      FLAGS="-d $TEST_ID -t $T -p $P"
      if [[ -n "$N" ]]; then
        FLAGS+=" -n $N"
      fi
      ;;
    p)
      FLAGS="-d $TEST_ID -p $P"
      ;;
  esac
  if [[ -n "$EXTRA_ARGS" ]]; then
    FLAGS+=" $EXTRA_ARGS"
  fi
fi

if [[ "$FORMAT" == "flags" ]]; then
  if [[ "$ENABLED_OUT" == "1" ]]; then
    printf '%s\n' "$FLAGS"
  fi
  exit 0
fi

cat <<SH
TEST_ID=$(printf '%q' "$TEST_ID")
TEST_NAME=$(printf '%q' "$NAME")
MODE=$(printf '%q' "$MODE")
FILE=$(printf '%q' "$FILE")
FILE_SIZE_BYTES=$(printf '%q' "$FILE_SIZE_BYTES")
USABLE_BYTES=$(printf '%q' "$USABLE_BYTES")
UNIT_BYTES=$(printf '%q' "$UNIT_BYTES")
ADJ_UNIT_BYTES=$(printf '%q' "$ADJ_UNIT_BYTES")
BPT=$(printf '%q' "${BPT:-}")
FORMULA=$(printf '%q' "$FORMULA")
P_POLICY=$(printf '%q' "$P_POLICY")
DEFAULT_T=$(printf '%q' "$DEFAULT_T")
ENABLED=$(printf '%q' "$ENABLED_OUT")
REASON=$(printf '%q' "$REASON")
T=$(printf '%q' "$T")
P=$(printf '%q' "$P")
N=$(printf '%q' "$N")
FLAGS=$(printf '%q' "$FLAGS")
SH
