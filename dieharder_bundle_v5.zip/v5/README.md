# Dieharder modular runner

This bundle contains a modular dieharder runner built around file-size-aware flag calculation for raw binary files.

## Files

- `scripts/common.sh`
- `scripts/dieharder_profiles.sh`
- `scripts/dieharder_calc_flags.sh`
- `scripts/dieharder_run_tests.sh`

## What it does

- Computes `-t`, `-p`, and where relevant `-n` from the input file size.
- Prefers scaling `-t` for variable-size tests instead of collapsing to `-t 1` too early.
- Keeps `p`-only handling for tests that should not receive a synthetic `-t`.
- Adds `--verbose` to summarize whether each test ended as `PASSED`, `WEAK`, `FAILED`, or `NO_DATA`.
- Writes:
  - per-test raw CSV output from dieharder,
  - per-test stderr logs,
  - one summary CSV with the chosen parameters, command line, parsed assessment summary, and profile formula used.

## What changed in this iteration

Several profiles now come from the actual dieharder implementation rather than rough guesses:

- `0` Birthdays
- `1` OPERM5
- `2` 32x32 Binary Rank
- `3` 6x8 Binary Rank
- `4` Bitstream
- `8` Count the 1s (stream)
- `9` Count the 1s (byte)
- `13` Squeeze
- `15` Runs
- `17` Marsaglia and Tsang GCD
- `200` RGB Bit Distribution
- `201` RGB Generalized Minimum Distance
- `202` RGB Permutations

Some fixed-size classic tests are also now much less over-conservative on file input:

- `10` Parking Lot
- `11` Minimum Distance 2d Circle
- `12` 3d Sphere Minimum Distance
- `6` OQSO
- `7` DNA

## Basic examples

```bash
./scripts/dieharder_calc_flags.sh --file ./archivo_aleatorio.bin --test 200
./scripts/dieharder_calc_flags.sh --file ./archivo_aleatorio.bin --test 1
./scripts/dieharder_run_tests.sh --file ./archivo_aleatorio.bin --tests 0,1,2,3 --verbose
./scripts/dieharder_run_tests.sh --file ./archivo_aleatorio.bin --all --verbose
```

## Notes

- `-n` in dieharder is `ntuple`, while `-p` controls the number of p-value samples.
- Test `14` is marked as skipped because dieharder itself labels it as `Do Not Use` in the test list.
- Not every profile is exact yet. Where the source code did not make byte consumption straightforward, the profile remains conservative.
- The summary CSV now includes `formula` and `bpt` so you can see whether the runner used a fixed estimate or an explicit bytes-per-tsample formula.

## Suggested next step

Add an empirical calibration mode that launches each test on a temporary larger file and refines the remaining conservative profiles from observed behaviour.


Version v5 notes
- Refined remaining profiles for tests 203-209 and adjusted Craps.
- Exact or near-exact defaults were aligned to published dieharder sample sizes gathered from manual/examples and community tables.
- 207 and 208 remain empirical profiles based on published default data volume because their internal per-sample cost is less transparent than the other tests.
