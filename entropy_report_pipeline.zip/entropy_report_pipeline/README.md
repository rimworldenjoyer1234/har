# Entropy Report Pipeline

Pipeline to run:
- NIST SP800-90B `ea_non_iid`
- `dieharder`
- generate a PDF report with Python ReportLab

## Structure

- `scripts/run_entropy_report.sh` — main entry point
- `scripts/run_sp80090b.sh` — runs `ea_non_iid`
- `scripts/parse_sp80090b.py` — parses SP800-90B output to JSON
- `scripts/parse_dieharder_csv.py` — parses dieharder CSV output to JSON
- `scripts/generate_entropy_report.py` — builds the final PDF report
- `results/` — output directory

## Example

```bash
./scripts/run_entropy_report.sh \
  --input /path/to/archivo_aleatorio.bin \
  --bits 8 \
  --sp80090b-bin /path/to/SP800-90B_EntropyAssessment/cpp/ea_non_iid \
  --dieharder-script ./scripts/dieharder_run_tests.sh \
  --output-dir ./results \
  --base-name entropy_report \
  --dieharder-all \
  --verbose
```

## Notes

- The script expects raw binary input for both tools.
- `dieharder_run_tests.sh` is expected to create:
  - a summary CSV
  - a detailed CSV with p-values/results
- The parser is resilient to both quoted and unquoted CSV fields.
- The PDF includes:
  - file metadata
  - SP800-90B summary
  - detailed SP800-90B estimates
  - dieharder execution summary
  - dieharder per-test summary table
  - reliability notes

## Future work

- Add charts per test using the parsed p-values
- Merge IID and non-IID SP800-90B workflows
- Add histograms and trend plots to the PDF
