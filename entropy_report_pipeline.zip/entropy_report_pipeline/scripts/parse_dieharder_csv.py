#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path


def to_float(value):
    if value is None:
        return None
    value = str(value).strip()
    if value == "":
        return None
    try:
        return float(value)
    except ValueError:
        return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", required=True)
    ap.add_argument("--detail", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    summary_rows = []
    detail_rows = []

    with open(args.summary, "r", encoding="utf-8", errors="replace", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            row["test_id"] = row.get("test_id") or row.get("test_num") or row.get("id")
            row["passed_count"] = int(row["passed_count"]) if row.get("passed_count") not in (None, "") else 0
            row["weak_count"] = int(row["weak_count"]) if row.get("weak_count") not in (None, "") else 0
            row["failed_count"] = int(row["failed_count"]) if row.get("failed_count") not in (None, "") else 0
            row["min_p"] = to_float(row.get("min_p"))
            row["max_p"] = to_float(row.get("max_p"))
            summary_rows.append(row)

    with open(args.detail, "r", encoding="utf-8", errors="replace", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            pval = (
                row.get("p-value")
                or row.get("p_value")
                or row.get("pvalue")
                or row.get("p")
            )
            row["p_value"] = to_float(pval)
            detail_rows.append(row)

    overall = {
        "tests_total": len(summary_rows),
        "tests_passed": sum(1 for r in summary_rows if str(r.get("overall_assessment", "")).upper() == "PASSED"),
        "tests_weak": sum(1 for r in summary_rows if str(r.get("overall_assessment", "")).upper() == "WEAK"),
        "tests_failed": sum(1 for r in summary_rows if str(r.get("overall_assessment", "")).upper() == "FAILED"),
        "tests_rewind_detected": sum(1 for r in summary_rows if str(r.get("rewind_flag", "")).upper() == "DETECTED"),
        "tests_rewind_possible": sum(1 for r in summary_rows if str(r.get("rewind_flag", "")).upper() == "POSSIBLE"),
    }

    data = {
        "overall": overall,
        "summary_rows": summary_rows,
        "detail_rows": detail_rows,
    }

    Path(args.output).write_text(json.dumps(data, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
