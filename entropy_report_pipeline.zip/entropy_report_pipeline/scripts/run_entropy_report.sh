#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<USAGE
Usage:
  $(basename "$0") --input FILE --bits N --sp80090b-bin PATH --dieharder-script PATH [options]

Required:
  --input FILE              Input binary file
  --bits N                  Bits per symbol, e.g. 8
  --sp80090b-bin PATH       Path to ea_non_iid
  --dieharder-script PATH   Path to dieharder_run_tests.sh

Optional:
  --output-dir DIR          Output directory (default: ./results)
  --base-name NAME          Base name for outputs (default: report_TIMESTAMP)
  --dieharder-tests LIST    Comma-separated test list
  --dieharder-all           Run all dieharder tests
  --verbose                 Enable verbose mode in dieharder runner if supported
  -h, --help                Show this help
USAGE
}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INPUT=""
BITS=""
SPBIN=""
DH_SCRIPT=""
OUTPUT_DIR="./results"
BASE_NAME="report_$(date +%Y%m%d_%H%M%S)"
DH_TESTS=""
DH_ALL=0
VERBOSE=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --input) INPUT="$2"; shift 2 ;;
    --bits) BITS="$2"; shift 2 ;;
    --sp80090b-bin) SPBIN="$2"; shift 2 ;;
    --dieharder-script) DH_SCRIPT="$2"; shift 2 ;;
    --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
    --base-name) BASE_NAME="$2"; shift 2 ;;
    --dieharder-tests) DH_TESTS="$2"; shift 2 ;;
    --dieharder-all) DH_ALL=1; shift ;;
    --verbose) VERBOSE=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage; exit 1 ;;
  esac
done

[[ -n "$INPUT" && -n "$BITS" && -n "$SPBIN" && -n "$DH_SCRIPT" ]] || { usage; exit 1; }
[[ -f "$INPUT" ]] || { echo "Input file not found: $INPUT" >&2; exit 1; }
[[ -x "$SPBIN" ]] || { echo "SP800-90B binary not executable: $SPBIN" >&2; exit 1; }
[[ -x "$DH_SCRIPT" ]] || { echo "dieharder script not executable: $DH_SCRIPT" >&2; exit 1; }
[[ $DH_ALL -eq 1 || -n "$DH_TESTS" ]] || { echo "Choose --dieharder-all or --dieharder-tests" >&2; exit 1; }

mkdir -p "$OUTPUT_DIR" "$OUTPUT_DIR/raw" "$OUTPUT_DIR/json" "$OUTPUT_DIR/pdf"

SP_LOG="$OUTPUT_DIR/raw/${BASE_NAME}_sp80090b.txt"
SP_JSON="$OUTPUT_DIR/json/${BASE_NAME}_sp80090b.json"
DH_RUN_LOG="$OUTPUT_DIR/raw/${BASE_NAME}_dieharder_runner.log"
DH_JSON="$OUTPUT_DIR/json/${BASE_NAME}_dieharder.json"
PDF_OUT="$OUTPUT_DIR/pdf/${BASE_NAME}.pdf"

# Run SP800-90B
"$SCRIPT_DIR/run_sp80090b.sh" --input "$INPUT" --bits "$BITS" --bin "$SPBIN" --output "$SP_LOG"
python3 "$SCRIPT_DIR/parse_sp80090b.py" --input "$SP_LOG" --output "$SP_JSON"

# Run dieharder and capture stdout for path extraction
DH_CMD=("$DH_SCRIPT" --file "$INPUT")
if [[ $DH_ALL -eq 1 ]]; then
  DH_CMD+=(--all)
else
  DH_CMD+=(--tests "$DH_TESTS")
fi
if [[ $VERBOSE -eq 1 ]]; then
  DH_CMD+=(--verbose)
fi

"${DH_CMD[@]}" | tee "$DH_RUN_LOG"

SUMMARY_CSV="$(grep -E '^\[INFO\] Summary CSV:' "$DH_RUN_LOG" | tail -1 | sed 's/^\[INFO\] Summary CSV: //')"
DETAIL_CSV="$(grep -E '^\[INFO\] Dieharder CSV:' "$DH_RUN_LOG" | tail -1 | sed 's/^\[INFO\] Dieharder CSV: //')"

[[ -n "$SUMMARY_CSV" && -f "$SUMMARY_CSV" ]] || { echo "Could not locate dieharder summary CSV" >&2; exit 1; }
[[ -n "$DETAIL_CSV" && -f "$DETAIL_CSV" ]] || { echo "Could not locate dieharder detail CSV" >&2; exit 1; }

python3 "$SCRIPT_DIR/parse_dieharder_csv.py" --summary "$SUMMARY_CSV" --detail "$DETAIL_CSV" --output "$DH_JSON"
python3 "$SCRIPT_DIR/generate_entropy_report.py" --sp80090b-json "$SP_JSON" --dieharder-json "$DH_JSON" --input-file "$INPUT" --output-pdf "$PDF_OUT"

echo "[INFO] SP800-90B log: $SP_LOG"
echo "[INFO] SP800-90B JSON: $SP_JSON"
echo "[INFO] dieharder JSON: $DH_JSON"
echo "[INFO] PDF report: $PDF_OUT"
