#!/usr/bin/env python3
import argparse
import json
import math
import os
from datetime import datetime
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)


def fmt_float(x, digits=6):
    if x is None:
        return "-"
    return f"{x:.{digits}f}"


def human_size(num_bytes: int) -> str:
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    v = float(num_bytes)
    for unit in units:
        if v < 1024.0 or unit == units[-1]:
            return f"{v:.2f} {unit}"
        v /= 1024.0
    return f"{num_bytes} B"


class NumberedDocTemplate(BaseDocTemplate):
    def __init__(self, filename, **kwargs):
        super().__init__(filename, **kwargs)
        frame = Frame(self.leftMargin, self.bottomMargin, self.width, self.height, id="normal")
        template = PageTemplate(id="main", frames=[frame], onPage=self._draw_header_footer)
        self.addPageTemplates([template])
        self.report_title = kwargs.get("report_title", "Entropy Assessment Report")

    def _draw_header_footer(self, canvas, doc):
        canvas.saveState()
        width, height = A4
        canvas.setStrokeColor(colors.HexColor("#D8DEE9"))
        canvas.line(doc.leftMargin, height - 16 * mm, width - doc.rightMargin, height - 16 * mm)
        canvas.line(doc.leftMargin, 14 * mm, width - doc.rightMargin, 14 * mm)
        canvas.setFont("Helvetica-Bold", 9)
        canvas.setFillColor(colors.HexColor("#2E3440"))
        canvas.drawString(doc.leftMargin, height - 12 * mm, self.report_title)
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#4C566A"))
        canvas.drawRightString(width - doc.rightMargin, height - 12 * mm, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        canvas.drawString(doc.leftMargin, 9 * mm, "Generated with dieharder + NIST SP800-90B")
        canvas.drawRightString(width - doc.rightMargin, 9 * mm, f"Page {canvas.getPageNumber()}")
        canvas.restoreState()


def build_table(data, col_widths=None, header_bg="#E5E9F0", body_font=8, header_font=8, repeat=1):
    table = Table(data, colWidths=col_widths, repeatRows=repeat)
    style = TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(header_bg)),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#2E3440")),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), header_font),
        ("FONTSIZE", (0, 1), (-1, -1), body_font),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("BACKGROUND", (0, 1), (-1, -1), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#D8DEE9")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8F9FB")]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("ALIGN", (0, 0), (-1, 0), "CENTER"),
    ])
    table.setStyle(style)
    return table


def paragraph_styles():
    ss = getSampleStyleSheet()
    styles = {
        "title": ParagraphStyle(
            "TitleCustom",
            parent=ss["Title"],
            fontName="Helvetica-Bold",
            fontSize=18,
            leading=22,
            textColor=colors.HexColor("#2E3440"),
            spaceAfter=8,
            alignment=TA_LEFT,
        ),
        "subtitle": ParagraphStyle(
            "SubtitleCustom",
            parent=ss["BodyText"],
            fontName="Helvetica",
            fontSize=9,
            leading=12,
            textColor=colors.HexColor("#4C566A"),
            spaceAfter=14,
        ),
        "h1": ParagraphStyle(
            "Heading1Custom",
            parent=ss["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=13,
            leading=16,
            textColor=colors.HexColor("#2E3440"),
            spaceBefore=10,
            spaceAfter=8,
        ),
        "h2": ParagraphStyle(
            "Heading2Custom",
            parent=ss["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=10.5,
            leading=13,
            textColor=colors.HexColor("#3B4252"),
            spaceBefore=8,
            spaceAfter=6,
        ),
        "body": ParagraphStyle(
            "BodyCustom",
            parent=ss["BodyText"],
            fontName="Helvetica",
            fontSize=9,
            leading=12,
            textColor=colors.HexColor("#2E3440"),
            spaceAfter=6,
        ),
        "small": ParagraphStyle(
            "SmallCustom",
            parent=ss["BodyText"],
            fontName="Helvetica",
            fontSize=8,
            leading=10,
            textColor=colors.HexColor("#4C566A"),
            spaceAfter=4,
        ),
        "center_small": ParagraphStyle(
            "CenterSmall",
            parent=ss["BodyText"],
            fontName="Helvetica",
            fontSize=8,
            leading=10,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#4C566A"),
        ),
    }
    return styles


def build_story(sp_data, dh_data, input_file, styles):
    story = []
    p = styles

    input_path = Path(input_file)
    size_bytes = input_path.stat().st_size if input_path.exists() else 0

    story.append(Paragraph("Entropy Assessment Report", p["title"]))
    story.append(Paragraph(
        f"Automatic report generated from <b>dieharder</b> and <b>NIST SP800-90B non-IID</b> for file <font name='Helvetica-Bold'>{input_path.name}</font>.",
        p["subtitle"],
    ))

    story.append(Paragraph("1. Input file", p["h1"]))
    meta_table = [
        ["Field", "Value"],
        ["Path", str(input_path)],
        ["Size", human_size(size_bytes)],
        ["SHA-256", sp_data.get("sha256", "-")],
        ["Bits per symbol", str(sp_data.get("bits_per_symbol", "-"))],
        ["Samples", str(sp_data.get("samples", "-"))],
        ["Distinct symbols", str(sp_data.get("distinct_symbols", "-"))],
        ["Binary symbols", str(sp_data.get("binary_symbols", "-"))],
    ]
    story.append(build_table(meta_table, col_widths=[45*mm, 130*mm]))
    story.append(Spacer(1, 5 * mm))

    story.append(Paragraph("2. SP800-90B summary", p["h1"]))
    final = sp_data.get("final", {})
    sp_summary = [
        ["Metric", "Value"],
        ["H_original", fmt_float(final.get("H_original"))],
        ["H_bitstring", fmt_float(final.get("H_bitstring"))],
        ["min(H_original, 8 × H_bitstring)", fmt_float(final.get("min_entropy_bound"))],
    ]
    story.append(build_table(sp_summary, col_widths=[90*mm, 40*mm]))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph(
        "The SP800-90B non-IID result is driven by the most conservative estimate. The final bound used here is the minimum between H_original and the scaled bitstring bound.",
        p["body"],
    ))

    story.append(Paragraph("3. SP800-90B detailed estimates", p["h1"]))
    estimates = sp_data.get("estimates", [])
    est_table = [["Section", "Estimate", "Value", "Bits"]]
    for item in estimates:
        est_table.append([
            str(item.get("section") or "-"),
            str(item.get("name") or "-"),
            fmt_float(item.get("value")),
            str(item.get("bits") or "-"),
        ])
    story.append(build_table(est_table, col_widths=[48*mm, 88*mm, 26*mm, 18*mm], body_font=7.5, header_font=8))

    story.append(PageBreak())
    story.append(Paragraph("4. dieharder summary", p["h1"]))
    overall = dh_data.get("overall", {})
    dh_summary = [
        ["Metric", "Value"],
        ["Total tests", str(overall.get("tests_total", 0))],
        ["PASSED", str(overall.get("tests_passed", 0))],
        ["WEAK", str(overall.get("tests_weak", 0))],
        ["FAILED", str(overall.get("tests_failed", 0))],
        ["Rewind detected", str(overall.get("tests_rewind_detected", 0))],
        ["Rewind possible", str(overall.get("tests_rewind_possible", 0))],
    ]
    story.append(build_table(dh_summary, col_widths=[70*mm, 35*mm]))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph(
        "A result marked with rewind or possible short input should be treated with caution because file reuse can bias the dieharder assessment when the input stream is exhausted.",
        p["body"],
    ))

    story.append(Paragraph("5. dieharder per-test summary", p["h1"]))
    rows = dh_data.get("summary_rows", [])
    per_test = [["ID", "Test", "Assessment", "Pass", "Weak", "Fail", "min p", "max p", "Rewind"]]
    for row in rows:
        per_test.append([
            str(row.get("test_id") or row.get("test_num") or row.get("show_num") or "-"),
            str(row.get("test_name") or row.get("name") or "-")[:34],
            str(row.get("overall_assessment") or "-"),
            str(row.get("passed_count", 0)),
            str(row.get("weak_count", 0)),
            str(row.get("failed_count", 0)),
            fmt_float(row.get("min_p"), 4),
            fmt_float(row.get("max_p"), 4),
            str(row.get("rewind_flag") or "-"),
        ])
    story.append(build_table(per_test, col_widths=[11*mm, 62*mm, 23*mm, 12*mm, 12*mm, 12*mm, 15*mm, 15*mm, 20*mm], body_font=7.3, header_font=7.6))

    reliability_rows = [r for r in rows if str(r.get("rewind_flag", "")).upper() in {"DETECTED", "POSSIBLE"}]
    if reliability_rows:
        story.append(Spacer(1, 5 * mm))
        story.append(Paragraph("6. Reliability notes", p["h1"]))
        rel_table = [["ID", "Test", "Rewind", "Note"]]
        for row in reliability_rows:
            rel_table.append([
                str(row.get("test_id") or "-"),
                str(row.get("test_name") or "-")[:40],
                str(row.get("rewind_flag") or "-"),
                str(row.get("reliability_note") or "-")[:60],
            ])
        story.append(build_table(rel_table, col_widths=[12*mm, 62*mm, 22*mm, 76*mm], body_font=7.5, header_font=8))

    return story


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sp80090b-json", required=True)
    ap.add_argument("--dieharder-json", required=True)
    ap.add_argument("--input-file", required=True)
    ap.add_argument("--output-pdf", required=True)
    args = ap.parse_args()

    sp_data = json.loads(Path(args.sp80090b_json).read_text(encoding="utf-8"))
    dh_data = json.loads(Path(args.dieharder_json).read_text(encoding="utf-8"))

    styles = paragraph_styles()
    doc = NumberedDocTemplate(
        args.output_pdf,
        pagesize=A4,
        leftMargin=18 * mm,
        rightMargin=18 * mm,
        topMargin=22 * mm,
        bottomMargin=18 * mm,
        report_title="Entropy Assessment Report",
    )
    story = build_story(sp_data, dh_data, args.input_file, styles)
    doc.build(story)


if __name__ == "__main__":
    main()
