#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<USAGE
Usage:
  $(basename "$0") --input FILE --bits N --bin EA_NON_IID_BIN --output OUTPUT_TXT

Options:
  --input FILE     Input binary file
  --bits N         Bits per symbol, e.g. 8
  --bin PATH       Path to ea_non_iid
  --output FILE    Output text log
USAGE
}

INPUT=""
BITS=""
BIN_PATH=""
OUTPUT=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --input) INPUT="$2"; shift 2 ;;
    --bits) BITS="$2"; shift 2 ;;
    --bin) BIN_PATH="$2"; shift 2 ;;
    --output) OUTPUT="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage; exit 1 ;;
  esac
done

[[ -n "$INPUT" && -n "$BITS" && -n "$BIN_PATH" && -n "$OUTPUT" ]] || { usage; exit 1; }
[[ -f "$INPUT" ]] || { echo "Input file not found: $INPUT" >&2; exit 1; }
[[ -x "$BIN_PATH" ]] || { echo "ea_non_iid binary not executable: $BIN_PATH" >&2; exit 1; }

mkdir -p "$(dirname "$OUTPUT")"
"$BIN_PATH" -v "$INPUT" "$BITS" | tee "$OUTPUT"
